import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const mountainsAroundTheWorld: SkillContent = {

    skillId: "mountainsAroundTheWorld",

    title: "Mountains Around the World",

    description:
        "Learn about famous mountains, mountain ranges, continents and how mountains are located around the world.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "geo-maw-001",
        skillId: "mountainsAroundTheWorld",
        question:
            "What is a mountain range?",
        stage: "recognise",
        options: [
            "A group of mountains connected together",
            "A single small hill",
            "A type of river",
            "A flat area of land"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "A mountain range is a group of mountains that are close together.",

        difficulty: 1,
        correctAnswer: "A group of mountains connected together",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-002",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which mountain range contains Mount Everest?",
        stage: "recognise",
        options: [
            "The Himalayas",
            "The Alps",
            "The Andes",
            "The Rockies"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mount Everest is part of the Himalayan mountain range.",

        difficulty: 1,
        correctAnswer: "The Himalayas",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-003",
        skillId: "mountainsAroundTheWorld",
        question:
            "Where are the Himalayas located?",
        stage: "recognise",
        options: [
            "Asia",
            "Africa",
            "Australia",
            "South America"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "The Himalayas are a large mountain range in Asia.",

        difficulty: 1,
        correctAnswer: "Asia",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-004",
        skillId: "mountainsAroundTheWorld",
        question:
            "What is the highest mountain above sea level?",
        stage: "recognise",
        options: [
            "Mount Everest",
            "Ben Nevis",
            "Mount Snowdon",
            "The Alps"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mount Everest is the highest mountain above sea level.",

        difficulty: 1,
        correctAnswer: "Mount Everest",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-005",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which mountain range is found in Europe?",
        stage: "recognise",
        options: [
            "The Alps",
            "The Himalayas",
            "The Andes",
            "The Rockies"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "The Alps stretch across several European countries.",

        difficulty: 1,
        correctAnswer: "The Alps",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-006",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which mountain range is found in South America?",
        stage: "recognise",
        options: [
            "The Andes",
            "The Alps",
            "The Himalayas",
            "The Pennines"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "The Andes are a long mountain range along western South America.",

        difficulty: 1,
        correctAnswer: "The Andes",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-007",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which mountain range is found in North America?",
        stage: "recognise",
        options: [
            "The Rocky Mountains",
            "The Himalayas",
            "The Alps",
            "The Andes"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "The Rocky Mountains are located in North America.",

        difficulty: 1,
        correctAnswer: "The Rocky Mountains",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-008",
        skillId: "mountainsAroundTheWorld",
        question:
            "What continent is the Andes mountain range in?",
        stage: "recognise",
        options: [
            "South America",
            "Europe",
            "Asia",
            "Africa"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "The Andes run along the western side of South America.",

        difficulty: 1,
        correctAnswer: "South America",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-009",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why do geographers use maps to study mountains?",
        stage: "recognise",
        options: [
            "To find where mountains are located",
            "To change mountains",
            "To create weather",
            "To remove mountains"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Maps help us locate and compare places around the world.",

        difficulty: 1,
        correctAnswer: "To find where mountains are located",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "maps"]
    },

    {
        id: "geo-maw-010",
        skillId: "mountainsAroundTheWorld",
        question:
            "What does a globe show?",
        stage: "recognise",
        options: [
            "A model of Earth",
            "Only mountains",
            "Only rivers",
            "A weather forecast"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "A globe is a model showing Earth's continents and oceans.",

        difficulty: 1,
        correctAnswer: "A model of Earth",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "maps"]
    },

    {
        id: "geo-maw-011",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why are some mountain areas difficult to live in?",
        stage: "recognise",
        options: [
            "They can be steep, cold and hard to travel through",
            "They have no land",
            "They have no weather",
            "They are always underwater"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mountain environments can be challenging because of their height and climate.",

        difficulty: 2,
        correctAnswer: "They can be steep, cold and hard to travel through",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-012",
        skillId: "mountainsAroundTheWorld",
        question:
            "What is a mountain environment?",
        stage: "recognise",
        options: [
            "The natural surroundings of a mountain area",
            "A type of map",
            "A city centre",
            "A river crossing"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "An environment includes the living and non-living features of an area.",

        difficulty: 2,
        correctAnswer: "The natural surroundings of a mountain area",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-013",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why do tourists visit mountains?",
        stage: "recognise",
        options: [
            "For activities such as climbing, walking and sightseeing",
            "To build cities",
            "To remove forests",
            "To stop rivers"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mountains attract visitors for recreation and exploration.",

        difficulty: 1,
        correctAnswer: "For activities such as climbing, walking and sightseeing",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-014",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which mountain is in the UK?",
        stage: "recognise",
        options: [
            "Ben Nevis",
            "Mount Everest",
            "K2",
            "Kilimanjaro"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Ben Nevis in Scotland is the highest mountain in the UK.",

        difficulty: 1,
        correctAnswer: "Ben Nevis",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains", "uk"]
    },

    {
        id: "geo-maw-015",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why are mountain ranges often shown on maps?",
        stage: "recognise",
        options: [
            "They are important features of Earth's surface",
            "They are invisible",
            "They are made by people",
            "They are only found in cities"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mountain ranges are major physical features of the Earth.",

        difficulty: 2,
        correctAnswer: "They are important features of Earth's surface",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "maps"]
    },

    {
        id: "geo-maw-016",
        skillId: "mountainsAroundTheWorld",
        question:
            "What can people compare about mountains around the world?",
        stage: "recognise",
        options: [
            "Height, location and features",
            "Only their names",
            "Only their colours",
            "Only their age"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Geographers compare mountains using different measurements and features.",

        difficulty: 2,
        correctAnswer: "Height, location and features",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-017",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why do mountain climates vary?",
        stage: "recognise",
        options: [
            "Height and location affect temperature and rainfall",
            "All mountains have identical weather",
            "Mountains control all weather",
            "Climate does not change"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Altitude and location influence mountain climates.",

        difficulty: 2,
        correctAnswer: "Height and location affect temperature and rainfall",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-018",
        skillId: "mountainsAroundTheWorld",
        question:
            "What type of map feature helps show height?",
        stage: "recognise",
        options: [
            "Contour lines",
            "Road signs",
            "Country names only",
            "Weather symbols"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Contour lines show changes in height on maps.",

        difficulty: 2,
        correctAnswer: "Contour lines",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "maps"]
    },

    {
        id: "geo-maw-019",
        skillId: "mountainsAroundTheWorld",
        question:
            "Why are mountains important around the world?",
        stage: "recognise",
        options: [
            "They provide habitats, resources and influence landscapes",
            "They have no effect",
            "They only create roads",
            "They prevent all life"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mountains are important natural features that support life.",

        difficulty: 2,
        correctAnswer: "They provide habitats, resources and influence landscapes",
        estimatedSeconds: 20,

        tags: ["geography", "year3", "mountains"]
    },

    {
        id: "geo-maw-020",
        skillId: "mountainsAroundTheWorld",
        question:
            "Which sentence best describes mountains around the world?",
        stage: "recognise",
        options: [
            "Mountains are found on different continents and have different features",
            "All mountains are the same",
            "Mountains only exist in one country",
            "Mountains cannot be studied"
        ],

        hint: "Think about the mountain, continent, map skill or geographical feature being described.",
        explanation:
            "Mountains vary in size, location and characteristics.",

        difficulty: 2,
        correctAnswer: "Mountains are found on different continents and have different features",
        estimatedSeconds: 25,

        tags: ["geography", "year3", "mountains"]
    }

    ]

};


export default mountainsAroundTheWorld;

export {

    mountainsAroundTheWorld

};

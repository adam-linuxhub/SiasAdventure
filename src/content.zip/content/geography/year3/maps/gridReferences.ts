import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const gridReferences: SkillContent = {

    skillId: "gridReferences",

    title: "Grid References",

    description:
        "Learn how grid references help us find places accurately on maps.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "geo-grid-001",
        skillId: "gridReferences",
        question: "What is a grid on a map?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "A pattern of lines that helps find places",
            "A type of road",
            "A large river",
            "A weather map"
        ],

        explanation:
            "Grid lines divide a map into squares, making places easier to find.",

        difficulty: 1,
        correctAnswer: "A pattern of lines that helps find places",
        estimatedSeconds: 15,

        tags: ["geography", "maps", "grid"]
    },

    {
        id: "geo-grid-002",
        skillId: "gridReferences",
        question: "Why do maps use grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "To help people find exact locations",
            "To make maps colourful",
            "To measure rainfall",
            "To show the weather"
        ],

        explanation:
            "Grid references help us identify a precise place on a map.",

        difficulty: 1,
        correctAnswer: "To help people find exact locations",
        estimatedSeconds: 15,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-003",
        skillId: "gridReferences",
        question: "What shape do grid lines usually make?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Squares",
            "Circles",
            "Triangles",
            "Stars"
        ],

        explanation:
            "Grid lines usually cross to form squares.",

        difficulty: 1,
        correctAnswer: "Squares",
        estimatedSeconds: 15,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-004",
        skillId: "gridReferences",
        question: "What do the numbers along the edges of a map help you do?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Find grid references",
            "Measure temperature",
            "Read the weather",
            "Find compass directions"
        ],

        explanation:
            "The numbers around the edge identify rows and columns of the grid.",

        difficulty: 1,
        correctAnswer: "Find grid references",
        estimatedSeconds: 15,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-005",
        skillId: "gridReferences",
        question: "What does a grid reference tell you?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Where something is on a map",
            "How tall a mountain is",
            "What the weather is like",
            "How old a building is"
        ],

        explanation:
            "A grid reference identifies the location of a place on a map.",

        difficulty: 1,
        correctAnswer: "Where something is on a map",
        estimatedSeconds: 15,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-006",
        skillId: "gridReferences",
        question: "Which map feature works with grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Grid lines",
            "Clouds",
            "Photographs",
            "Traffic lights"
        ],

        explanation:
            "Grid references are based on the grid lines printed on the map.",

        difficulty: 1,
        correctAnswer: "Grid lines",
        estimatedSeconds: 15,

        tags: ["geography", "maps"]
    },

    {
        id: "geo-grid-007",
        skillId: "gridReferences",
        question: "Grid references help you find places more...",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Accurately",
            "Slowly",
            "Randomly",
            "Quietly"
        ],

        explanation:
            "Grid references make finding places much more accurate.",

        difficulty: 1,
        correctAnswer: "Accurately",
        estimatedSeconds: 15,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-008",
        skillId: "gridReferences",
        question: "Who might use grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Walkers",
            "Doctors",
            "Chefs",
            "Musicians"
        ],

        explanation:
            "Walkers often use maps and grid references to navigate.",

        difficulty: 1,
        correctAnswer: "Walkers",
        estimatedSeconds: 20,

        tags: ["geography", "navigation"]
    },

    {
        id: "geo-grid-009",
        skillId: "gridReferences",
        question: "Why are maps divided into squares?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "To make places easier to find",
            "To decorate the map",
            "To make the paper stronger",
            "To show the weather"
        ],

        explanation:
            "Squares help us describe locations clearly.",

        difficulty: 1,
        correctAnswer: "To make places easier to find",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-010",
        skillId: "gridReferences",
        question: "Which statement is true?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Grid references help locate places on maps.",
            "Grid references show the weather.",
            "Grid references measure distance.",
            "Every map has no grid."
        ],

        explanation:
            "Grid references are used to identify locations.",

        difficulty: 1,
        correctAnswer: "Grid references help locate places on maps.",
        estimatedSeconds: 20,

        tags: ["geography", "maps"]
    },

    {
        id: "geo-grid-011",
        skillId: "gridReferences",
        question: "Why are grid references useful when giving directions?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "They identify an exact location.",
            "They tell the temperature.",
            "They show the time.",
            "They describe the weather."
        ],

        explanation:
            "A grid reference tells someone exactly where to look on the map.",

        difficulty: 2,
        correctAnswer: "They identify an exact location.",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-012",
        skillId: "gridReferences",
        question: "If two people use the same grid reference, what should they find?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "The same place",
            "Different countries",
            "Different maps",
            "Different weather"
        ],

        explanation:
            "A grid reference identifies one location on a particular map.",

        difficulty: 2,
        correctAnswer: "The same place",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-013",
        skillId: "gridReferences",
        question: "Why do emergency services sometimes use grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "They help identify locations accurately.",
            "They predict storms.",
            "They measure rivers.",
            "They count buildings."
        ],

        explanation:
            "Accurate locations help emergency services find places quickly.",

        difficulty: 2,
        correctAnswer: "They help identify locations accurately.",
        estimatedSeconds: 20,

        tags: ["geography", "navigation"]
    },

    {
        id: "geo-grid-014",
        skillId: "gridReferences",
        question: "What should you look for before using a grid reference?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "The grid lines on the map",
            "The weather forecast",
            "A photograph",
            "A ruler"
        ],

        explanation:
            "Grid references only work if the map has a grid.",

        difficulty: 2,
        correctAnswer: "The grid lines on the map",
        estimatedSeconds: 20,

        tags: ["geography", "maps"]
    },

    {
        id: "geo-grid-015",
        skillId: "gridReferences",
        question: "Why do maps use both rows and columns?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "To identify each square accurately",
            "To make the map colourful",
            "To show hills",
            "To show rivers only"
        ],

        explanation:
            "Rows and columns allow every square to be identified.",

        difficulty: 2,
        correctAnswer: "To identify each square accurately",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-016",
        skillId: "gridReferences",
        question: "Which activity is most likely to need grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Finding a campsite on a map",
            "Cooking dinner",
            "Watching television",
            "Painting a picture"
        ],

        explanation:
            "Grid references are useful when finding exact places on maps.",

        difficulty: 2,
        correctAnswer: "Finding a campsite on a map",
        estimatedSeconds: 20,

        tags: ["geography", "navigation"]
    },

    {
        id: "geo-grid-017",
        skillId: "gridReferences",
        question: "What is the main purpose of map grids?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "To organise the map into easy-to-find sections",
            "To show the weather",
            "To measure population",
            "To mark country flags"
        ],

        explanation:
            "Grid squares help users locate places quickly.",

        difficulty: 2,
        correctAnswer: "To organise the map into easy-to-find sections",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-018",
        skillId: "gridReferences",
        question: "Why are grid references easier than saying 'near the middle'?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "They are much more precise.",
            "They are shorter words.",
            "They use colours.",
            "They only work in cities."
        ],

        explanation:
            "Grid references give exact positions rather than rough descriptions.",

        difficulty: 2,
        correctAnswer: "They are much more precise.",
        estimatedSeconds: 20,

        tags: ["geography", "grid"]
    },

    {
        id: "geo-grid-019",
        skillId: "gridReferences",
        question: "Which map skill uses grid references?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "Finding locations accurately",
            "Predicting rainfall",
            "Measuring wind speed",
            "Finding the date"
        ],

        explanation:
            "Grid references are one of the main map-reading skills.",

        difficulty: 2,
        correctAnswer: "Finding locations accurately",
        estimatedSeconds: 20,

        tags: ["geography", "map-skills"]
    },

    {
        id: "geo-grid-020",
        skillId: "gridReferences",
        question: "Which sentence best describes a grid reference?",
        hint: "Think about what map grids are used for.",
        stage: "recognise",
        options: [
            "It helps identify the exact position of a place on a map.",
            "It tells you the weather forecast.",
            "It measures the height of mountains.",
            "It shows how old a town is."
        ],

        explanation:
            "Grid references are used to locate places accurately on maps.",

        difficulty: 2,
        correctAnswer: "It helps identify the exact position of a place on a map.",
        estimatedSeconds: 20,

        tags: ["geography", "grid", "maps", "map-skills"]
    }

    ]

};


export default gridReferences;

export {

    gridReferences

};

import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const riverBasics: SkillContent = {

    skillId: "riverBasics",

    title: "River Basics",

    description:
        "Learn what rivers are, where they start, where they flow and key river vocabulary.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "geo-riv-001",
        skillId: "riverBasics",
        question:
            "What is a river?",
        stage: "recognise",
        options: [
            "A flowing body of water moving towards another place",
            "A mountain made of rock",
            "A type of weather",
            "A human-made road"
        ],

        explanation:
            "A river is a natural flow of water that moves across the land.",

        difficulty: 1,
        correctAnswer: "A flowing body of water moving towards another place",
        estimatedSeconds: 20,
        hint: "Think about what makes a river different from mountains, roads and weather.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-002",
        skillId: "riverBasics",
        question:
            "Where does a river usually begin?",
        stage: "recognise",
        options: [
            "At its source",
            "At its mouth",
            "In the sea",
            "In a town"
        ],

        explanation:
            "The source is where a river begins, often in high land.",

        difficulty: 1,
        correctAnswer: "At its source",
        estimatedSeconds: 20,
        hint: "Every river has a beginning. What is that starting point called?",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-003",
        skillId: "riverBasics",
        question:
            "What is the mouth of a river?",
        stage: "recognise",
        options: [
            "The place where the river meets a sea, lake or another river",
            "The beginning of the river",
            "The deepest part of the river",
            "The side of a mountain"
        ],

        explanation:
            "The mouth is where a river ends and joins another body of water.",

        difficulty: 1,
        correctAnswer: "The place where the river meets a sea, lake or another river",
        estimatedSeconds: 20,
        hint: "Imagine following a river until it can flow no further.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-004",
        skillId: "riverBasics",
        question:
            "What is the path a river flows along called?",
        stage: "recognise",
        options: [
            "A channel",
            "A climate",
            "A continent",
            "A coastline"
        ],

        explanation:
            "The channel is the route the river follows.",

        difficulty: 1,
        correctAnswer: "A channel",
        estimatedSeconds: 20,
        hint: "Picture the route water follows between its banks.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-005",
        skillId: "riverBasics",
        question:
            "Which direction does water in a river usually flow?",
        stage: "recognise",
        options: [
            "From higher land to lower land",
            "From lower land to higher land",
            "Only upwards",
            "In circles"
        ],

        explanation:
            "Gravity causes rivers to flow downhill from higher to lower areas.",

        difficulty: 1,
        correctAnswer: "From higher land to lower land",
        estimatedSeconds: 20,
        hint: "Water follows gravity, not the other way around.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-006",
        skillId: "riverBasics",
        question:
            "What is a tributary?",
        stage: "recognise",
        options: [
            "A smaller river that joins a larger river",
            "The end of a river",
            "A river bridge",
            "A type of mountain"
        ],

        explanation:
            "Tributaries add water to a main river.",

        difficulty: 1,
        correctAnswer: "A smaller river that joins a larger river",
        estimatedSeconds: 20,
        hint: "Think about what happens when two rivers meet.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-007",
        skillId: "riverBasics",
        question:
            "Why are rivers important?",
        stage: "recognise",
        options: [
            "They provide water and support life",
            "They stop all plants growing",
            "They make land disappear",
            "They prevent animals living"
        ],

        explanation:
            "Rivers provide water for people, animals and plants.",

        difficulty: 1,
        correctAnswer: "They provide water and support life",
        estimatedSeconds: 20,
        hint: "Consider why people, plants and animals all depend on rivers.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-008",
        skillId: "riverBasics",
        question:
            "What is a river basin?",
        stage: "recognise",
        options: [
            "The area of land drained by a river and its tributaries",
            "A swimming pool",
            "A type of bridge",
            "The river mouth"
        ],

        explanation:
            "A river basin includes the land where water drains into a river system.",

        difficulty: 2,
        correctAnswer: "The area of land drained by a river and its tributaries",
        estimatedSeconds: 25,
        hint: "Imagine every raindrop flowing towards the same river system.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-009",
        skillId: "riverBasics",
        question:
            "What is the source of a river?",
        stage: "recognise",
        options: [
            "Where the river starts",
            "Where the river ends",
            "A bridge across a river",
            "A place where fish live"
        ],

        explanation:
            "The source is the starting point of a river.",

        difficulty: 1,
        correctAnswer: "Where the river starts",
        estimatedSeconds: 20,
        hint: "Source means where something begins, not where it finishes.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-010",
        skillId: "riverBasics",
        question:
            "Where are many river sources found?",
        stage: "recognise",
        options: [
            "In hills or mountains",
            "In shopping centres",
            "In deserts only",
            "In cities only"
        ],

        explanation:
            "Many rivers begin in high areas where water collects.",

        difficulty: 1,
        correctAnswer: "In hills or mountains",
        estimatedSeconds: 20,
        hint: "Rain often collects first in the highest places.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-011",
        skillId: "riverBasics",
        question:
            "What happens when small streams join together?",
        stage: "recognise",
        options: [
            "They can form a larger river",
            "They disappear immediately",
            "They become mountains",
            "They stop moving"
        ],

        explanation:
            "Small streams can join to create larger rivers.",

        difficulty: 2,
        correctAnswer: "They can form a larger river",
        estimatedSeconds: 20,
        hint: "Small streams can work together to make something bigger.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-012",
        skillId: "riverBasics",
        question:
            "What does a river carry as it flows?",
        stage: "recognise",
        options: [
            "Water and sometimes sediment",
            "Only air",
            "Only sunlight",
            "Buildings"
        ],

        explanation:
            "Rivers transport water and materials such as soil and rocks.",

        difficulty: 2,
        correctAnswer: "Water and sometimes sediment",
        estimatedSeconds: 20,
        hint: "Fast-moving water can carry more than just water.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-013",
        skillId: "riverBasics",
        question:
            "What is sediment?",
        stage: "recognise",
        options: [
            "Small pieces of rock and soil carried by water",
            "A type of animal",
            "A weather event",
            "A river bridge"
        ],

        explanation:
            "Sediment includes materials moved by rivers.",

        difficulty: 2,
        correctAnswer: "Small pieces of rock and soil carried by water",
        estimatedSeconds: 20,
        hint: "Look for the option describing tiny natural materials moved by water.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-014",
        skillId: "riverBasics",
        question:
            "Why do rivers often have bends?",
        stage: "recognise",
        options: [
            "Water changes direction as it moves across land",
            "Rivers are built by people",
            "The water stops flowing",
            "The river becomes a road"
        ],

        explanation:
            "Rivers naturally change direction as they flow.",

        difficulty: 2,
        correctAnswer: "Water changes direction as it moves across land",
        estimatedSeconds: 20,
        hint: "Water doesn't always travel in a perfectly straight line.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-015",
        skillId: "riverBasics",
        question:
            "What is a waterfall?",
        stage: "recognise",
        options: [
            "Water flowing over a steep drop",
            "A frozen river",
            "A type of lake",
            "A river source"
        ],

        explanation:
            "A waterfall forms when water falls over a steep section of land.",

        difficulty: 1,
        correctAnswer: "Water flowing over a steep drop",
        estimatedSeconds: 20,
        hint: "Picture a river suddenly dropping over a cliff edge.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-016",
        skillId: "riverBasics",
        question:
            "How do rivers help people?",
        stage: "recognise",
        options: [
            "They provide water, transport and resources",
            "They prevent farming",
            "They stop travel",
            "They remove all wildlife"
        ],

        explanation:
            "People use rivers for many important activities.",

        difficulty: 2,
        correctAnswer: "They provide water, transport and resources",
        estimatedSeconds: 20,
        hint: "Think about several different ways people benefit from rivers.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-017",
        skillId: "riverBasics",
        question:
            "What happens when a river reaches the sea?",
        stage: "recognise",
        options: [
            "The river ends at its mouth",
            "The river starts again",
            "The river becomes a mountain",
            "The river stops being water"
        ],

        explanation:
            "A river usually ends where it meets the sea or another body of water.",

        difficulty: 1,
        correctAnswer: "The river ends at its mouth",
        estimatedSeconds: 20,
        hint: "A river has a name for the place where its journey finishes.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-018",
        skillId: "riverBasics",
        question:
            "Why do rivers change the land around them?",
        stage: "recognise",
        options: [
            "They move water and sediment",
            "They create buildings",
            "They stop weather",
            "They remove gravity"
        ],

        explanation:
            "Moving water can wear away and deposit materials.",

        difficulty: 2,
        correctAnswer: "They move water and sediment",
        estimatedSeconds: 20,
        hint: "Moving water can shape the land over many years.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-019",
        skillId: "riverBasics",
        question:
            "Which words describe parts of a river?",
        stage: "recognise",
        options: [
            "Source, channel and mouth",
            "Roof, wall and door",
            "Leaf, stem and root",
            "Road, car and bridge"
        ],

        explanation:
            "Source, channel and mouth are key river features.",

        difficulty: 1,
        correctAnswer: "Source, channel and mouth",
        estimatedSeconds: 20,
        hint: "Choose the words that all belong to river geography.",

        tags: ["geography", "year3", "rivers"]
    },

    {
        id: "geo-riv-020",
        skillId: "riverBasics",
        question:
            "Which sentence best describes a river?",
        stage: "recognise",
        options: [
            "A flowing body of water that travels from its source to its mouth",
            "A type of mountain",
            "A man-made road",
            "A weather pattern"
        ],

        explanation:
            "A river is a flowing natural water system.",

        difficulty: 2,
        correctAnswer: "A flowing body of water that travels from its source to its mouth",
        estimatedSeconds: 25,
        hint: "Include where a river begins and where it finishes.",

        tags: ["geography", "year3", "rivers"]
    }

    ]

};


export default riverBasics;

export {

    riverBasics

};

import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const measuringWeather: SkillContent = {

    skillId: "measuringWeather",

    title: "Measuring Weather",

    description:
        "Learn how weather is measured using different instruments and how weather data is recorded.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "geo-mw-001",
        skillId: "measuringWeather",
        question:
            "Why do scientists measure the weather?",
        stage: "recognise",
        options: [
            "To understand weather patterns and make forecasts",
            "To change the weather",
            "To stop seasons happening",
            "To create storms"
        ],

        explanation:
            "Measuring weather helps scientists understand conditions and predict future weather.",

        difficulty: 1,
        correctAnswer: "To understand weather patterns and make forecasts",
        estimatedSeconds: 20,

        hint: "Think about why keeping weather records is useful days or weeks later.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-002",
        skillId: "measuringWeather",
        question:
            "Which instrument measures temperature?",
        stage: "recognise",
        options: [
            "Thermometer",
            "Rain gauge",
            "Anemometer",
            "Wind vane"
        ],

        explanation:
            "A thermometer measures how hot or cold the air is.",

        difficulty: 1,
        correctAnswer: "Thermometer",
        estimatedSeconds: 20,

        hint: "Match the instrument to what it measures, not what it looks like.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-003",
        skillId: "measuringWeather",
        question:
            "Which instrument measures rainfall?",
        stage: "recognise",
        options: [
            "Rain gauge",
            "Thermometer",
            "Compass",
            "Barometer"
        ],

        explanation:
            "A rain gauge collects and measures the amount of rainfall.",

        difficulty: 1,
        correctAnswer: "Rain gauge",
        estimatedSeconds: 20,

        hint: "Which tool is designed to collect falling water?",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-004",
        skillId: "measuringWeather",
        question:
            "Which instrument measures wind speed?",
        stage: "recognise",
        options: [
            "Anemometer",
            "Rain gauge",
            "Thermometer",
            "Map key"
        ],

        explanation:
            "An anemometer measures how fast the wind is moving.",

        difficulty: 1,
        correctAnswer: "Anemometer",
        estimatedSeconds: 20,

        hint: "Think about what 'speed' means when describing wind.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-005",
        skillId: "measuringWeather",
        question:
            "What does a wind vane show?",
        stage: "recognise",
        options: [
            "The direction the wind is blowing from",
            "The temperature",
            "The amount of rainfall",
            "The height of mountains"
        ],

        explanation:
            "A wind vane shows wind direction.",

        difficulty: 1,
        correctAnswer: "The direction the wind is blowing from",
        estimatedSeconds: 20,

        hint: "Direction tells you where something comes from, not how fast it moves.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-006",
        skillId: "measuringWeather",
        question:
            "Which weather measurement tells us how hot or cold the air is?",
        stage: "recognise",
        options: [
            "Temperature",
            "Rainfall",
            "Wind direction",
            "Cloud cover"
        ],

        explanation:
            "Temperature measures how hot or cold the air is.",

        difficulty: 1,
        correctAnswer: "Temperature",
        estimatedSeconds: 20,

        hint: "Choose the measurement that tells you how warm or cold the air feels.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-007",
        skillId: "measuringWeather",
        question:
            "What does a rain gauge collect?",
        stage: "recognise",
        options: [
            "Rainwater",
            "Wind",
            "Sunlight",
            "Clouds"
        ],

        explanation:
            "A rain gauge collects rain so the amount can be measured.",

        difficulty: 1,
        correctAnswer: "Rainwater",
        estimatedSeconds: 20,

        hint: "Imagine leaving the instrument outside during a rainy day.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-008",
        skillId: "measuringWeather",
        question:
            "What unit might be used to measure rainfall?",
        stage: "recognise",
        options: [
            "Millimetres",
            "Kilometres",
            "Degrees",
            "Litres per person"
        ],

        explanation:
            "Rainfall is commonly measured in millimetres.",

        difficulty: 2,
        correctAnswer: "Millimetres",
        estimatedSeconds: 20,

        hint: "Rainfall measures depth, not distance or weight.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-009",
        skillId: "measuringWeather",
        question:
            "What unit is used to measure temperature?",
        stage: "recognise",
        options: [
            "Degrees Celsius",
            "Metres",
            "Kilograms",
            "Seconds"
        ],

        explanation:
            "Temperature is often measured in degrees Celsius in the UK.",

        difficulty: 1,
        correctAnswer: "Degrees Celsius",
        estimatedSeconds: 20,

        hint: "Look for the unit used on weather forecasts in the UK.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-010",
        skillId: "measuringWeather",
        question:
            "What is cloud cover?",
        stage: "recognise",
        options: [
            "How much of the sky is covered by clouds",
            "The height of clouds",
            "The speed of clouds",
            "The colour of the sky only"
        ],

        explanation:
            "Cloud cover describes how much of the sky has clouds.",

        difficulty: 2,
        correctAnswer: "How much of the sky is covered by clouds",
        estimatedSeconds: 20,

        hint: "Think about how much of the sky you can see filled with clouds.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-011",
        skillId: "measuringWeather",
        question:
            "Why do weather stations collect data?",
        stage: "recognise",
        options: [
            "To record and study weather conditions",
            "To control the weather",
            "To create clouds",
            "To stop rainfall"
        ],

        explanation:
            "Weather stations collect information about the atmosphere.",

        difficulty: 1,
        correctAnswer: "To record and study weather conditions",
        estimatedSeconds: 20,

        hint: "Why would scientists keep collecting the same information every day?",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-012",
        skillId: "measuringWeather",
        question:
            "What is a weather chart used for?",
        stage: "recognise",
        options: [
            "Showing and comparing weather information",
            "Showing only roads",
            "Building mountains",
            "Measuring rivers"
        ],

        explanation:
            "Charts help people understand weather data.",

        difficulty: 1,
        correctAnswer: "Showing and comparing weather information",
        estimatedSeconds: 20,

        hint: "Charts help organise information so it is easier to compare.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-013",
        skillId: "measuringWeather",
        question:
            "Why do scientists record weather over time?",
        stage: "recognise",
        options: [
            "To find patterns and changes",
            "To stop weather changing",
            "To remove clouds",
            "To create seasons"
        ],

        explanation:
            "Long-term records help scientists understand weather patterns.",

        difficulty: 2,
        correctAnswer: "To find patterns and changes",
        estimatedSeconds: 20,

        hint: "Many observations over time reveal trends that one day cannot.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-014",
        skillId: "measuringWeather",
        question:
            "What is a weather diary?",
        stage: "recognise",
        options: [
            "A record of daily weather observations",
            "A book of maps only",
            "A list of mountains",
            "A type of instrument"
        ],

        explanation:
            "A weather diary records observations such as temperature and rainfall.",

        difficulty: 1,
        correctAnswer: "A record of daily weather observations",
        estimatedSeconds: 20,

        hint: "Think of a diary that records weather instead of personal events.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-015",
        skillId: "measuringWeather",
        question:
            "Which information could be recorded in a weather diary?",
        stage: "recognise",
        options: [
            "Temperature, rainfall and wind",
            "House prices",
            "Population numbers",
            "Road distances"
        ],

        explanation:
            "Weather diaries record weather conditions.",

        difficulty: 1,
        correctAnswer: "Temperature, rainfall and wind",
        estimatedSeconds: 20,

        hint: "Choose the items someone could observe outside each day.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-016",
        skillId: "measuringWeather",
        question:
            "What does a forecast use weather measurements for?",
        stage: "recognise",
        options: [
            "Predicting future weather",
            "Changing the climate",
            "Moving rivers",
            "Creating mountains"
        ],

        explanation:
            "Weather forecasts use data to predict likely conditions.",

        difficulty: 2,
        correctAnswer: "Predicting future weather",
        estimatedSeconds: 20,

        hint: "Forecasts rely on today's information to estimate tomorrow's weather.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-017",
        skillId: "measuringWeather",
        question:
            "Why are different instruments needed to measure weather?",
        stage: "recognise",
        options: [
            "Different parts of weather need different measurements",
            "One instrument cannot measure everything",
            "Weather instruments are decorative",
            "They are used for maps"
        ],

        explanation:
            "Each instrument measures a different weather feature.",

        difficulty: 2,
        correctAnswer: "Different parts of weather need different measurements",
        estimatedSeconds: 20,

        hint: "Each instrument has one special job rather than doing everything.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-018",
        skillId: "measuringWeather",
        question:
            "Which instrument would you use to measure wind direction?",
        stage: "recognise",
        options: [
            "Wind vane",
            "Rain gauge",
            "Thermometer",
            "Anemometer"
        ],

        explanation:
            "A wind vane shows the direction the wind comes from.",

        difficulty: 2,
        correctAnswer: "Wind vane",
        estimatedSeconds: 20,

        hint: "Wind direction is different from wind speed.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-019",
        skillId: "measuringWeather",
        question:
            "Why is accurate weather data important?",
        stage: "recognise",
        options: [
            "It helps people prepare and make decisions",
            "It stops all bad weather",
            "It changes seasons",
            "It controls nature"
        ],

        explanation:
            "Accurate weather information helps people plan safely.",

        difficulty: 2,
        correctAnswer: "It helps people prepare and make decisions",
        estimatedSeconds: 20,

        hint: "Reliable information helps people decide what to do.",
        tags: ["geography", "year3", "weather"]
    },

    {
        id: "geo-mw-020",
        skillId: "measuringWeather",
        question:
            "Which sentence best describes measuring weather?",
        stage: "recognise",
        options: [
            "Scientists use instruments to record weather conditions",
            "Weather cannot be measured",
            "Only rain can be measured",
            "Weather instruments change the atmosphere"
        ],

        explanation:
            "Weather instruments help us collect information about the atmosphere.",

        difficulty: 2,
        correctAnswer: "Scientists use instruments to record weather conditions",
        estimatedSeconds: 25,

        hint: "Focus on measuring and recording rather than changing weather.",
        tags: ["geography", "year3", "weather"]
    }

    ]

};


export default measuringWeather;

export {

    measuringWeather

};

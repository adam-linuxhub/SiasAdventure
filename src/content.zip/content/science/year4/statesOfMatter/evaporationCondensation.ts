import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const evaporationCondensation: SkillContent = {

    skillId: "evaporationCondensation",

    title: "Evaporation and Condensation",

    description:
        "Learn how evaporation and condensation happen and where they occur in everyday life.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "sci-evap-cond-001",
        skillId: "evaporationCondensation",
        question: "What is evaporation?",
        stage: "recognise",
        options: [
            "A liquid changing into a gas",
            "A gas changing into a liquid",
            "A solid changing into a liquid",
            "A liquid changing into a solid"
        ],

        explanation:
            "Evaporation is when a liquid changes into a gas.",

        difficulty: 1,
        correctAnswer: "A liquid changing into a gas",
        estimatedSeconds: 15,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-002",
        skillId: "evaporationCondensation",
        question: "What is condensation?",
        stage: "recognise",
        options: [
            "A gas changing into a liquid",
            "A liquid changing into a gas",
            "A solid changing into a liquid",
            "A liquid changing into a solid"
        ],

        explanation:
            "Condensation happens when a gas cools and becomes a liquid.",

        difficulty: 1,
        correctAnswer: "A gas changing into a liquid",
        estimatedSeconds: 15,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-003",
        skillId: "evaporationCondensation",
        question: "What happens to a puddle on a warm sunny day?",
        stage: "recognise",
        options: [
            "It evaporates.",
            "It freezes.",
            "It turns into ice.",
            "It becomes solid."
        ],

        explanation:
            "The water slowly evaporates into the air.",

        difficulty: 1,
        correctAnswer: "It evaporates.",
        estimatedSeconds: 15,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-004",
        skillId: "evaporationCondensation",
        question: "What forms on the outside of a cold drinks can?",
        stage: "recognise",
        options: [
            "Tiny drops of water",
            "Ice cubes",
            "Steam",
            "Smoke"
        ],

        explanation:
            "Water vapour in the air condenses into tiny liquid droplets.",

        difficulty: 1,
        correctAnswer: "Tiny drops of water",
        estimatedSeconds: 15,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-005",
        skillId: "evaporationCondensation",
        question: "Which process dries wet clothes?",
        stage: "recognise",
        options: [
            "Evaporation",
            "Condensation",
            "Freezing",
            "Melting"
        ],

        explanation:
            "The water in the clothes evaporates into the air.",

        difficulty: 1,
        correctAnswer: "Evaporation",
        estimatedSeconds: 15,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-006",
        skillId: "evaporationCondensation",
        question: "What is water vapour?",
        stage: "recognise",
        options: [
            "Water in its gas state",
            "Frozen water",
            "Liquid water",
            "A type of cloud"
        ],

        explanation:
            "Water vapour is the invisible gas form of water.",

        difficulty: 1,
        correctAnswer: "Water in its gas state",
        estimatedSeconds: 15,

        tags: ["science", "water-vapour"]
    },

    {
        id: "sci-evap-cond-007",
        skillId: "evaporationCondensation",
        question: "Which process needs cooling?",
        stage: "recognise",
        options: [
            "Condensation",
            "Evaporation",
            "Melting",
            "Boiling"
        ],

        explanation:
            "Condensation happens when a gas cools.",

        difficulty: 1,
        correctAnswer: "Condensation",
        estimatedSeconds: 15,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-008",
        skillId: "evaporationCondensation",
        question: "Which process happens when water is heated?",
        stage: "recognise",
        options: [
            "Evaporation",
            "Freezing",
            "Condensation",
            "Cooling"
        ],

        explanation:
            "Heating gives water enough energy to become water vapour.",

        difficulty: 1,
        correctAnswer: "Evaporation",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-009",
        skillId: "evaporationCondensation",
        question: "What is most likely to happen to water left in a shallow dish?",
        stage: "recognise",
        options: [
            "It slowly evaporates.",
            "It freezes.",
            "It becomes thicker.",
            "It turns into a rock."
        ],

        explanation:
            "Over time, water evaporates into the air.",

        difficulty: 1,
        correctAnswer: "It slowly evaporates.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-010",
        skillId: "evaporationCondensation",
        question: "Which statement is true?",
        stage: "recognise",
        options: [
            "Evaporation and condensation are opposite processes.",
            "They both make solids.",
            "Both only happen below 0°C.",
            "Neither changes the state of matter."
        ],

        explanation:
            "Evaporation changes liquid to gas, while condensation changes gas to liquid.",

        difficulty: 1,
        correctAnswer: "Evaporation and condensation are opposite processes.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation", "condensation"]
    },

    {
        id: "sci-evap-cond-011",
        skillId: "evaporationCondensation",
        question: "Why do wet clothes dry faster on a warm day?",
        stage: "recognise",
        options: [
            "Evaporation happens more quickly.",
            "The clothes freeze.",
            "Condensation increases.",
            "The water becomes solid."
        ],

        explanation:
            "Warmer temperatures increase the rate of evaporation.",

        difficulty: 2,
        correctAnswer: "Evaporation happens more quickly.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-012",
        skillId: "evaporationCondensation",
        question: "Why do bathroom mirrors mist up after a hot shower?",
        stage: "recognise",
        options: [
            "Water vapour condenses on the cool mirror.",
            "The mirror melts.",
            "The mirror freezes.",
            "The glass evaporates."
        ],

        explanation:
            "Warm water vapour cools on the mirror and forms tiny droplets.",

        difficulty: 2,
        correctAnswer: "Water vapour condenses on the cool mirror.",
        estimatedSeconds: 20,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-013",
        skillId: "evaporationCondensation",
        question: "Which process changes water vapour back into liquid water?",
        stage: "recognise",
        options: [
            "Condensation",
            "Evaporation",
            "Melting",
            "Boiling"
        ],

        explanation:
            "Condensation changes a gas into a liquid.",

        difficulty: 2,
        correctAnswer: "Condensation",
        estimatedSeconds: 20,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-014",
        skillId: "evaporationCondensation",
        question: "What happens to water particles during evaporation?",
        stage: "recognise",
        options: [
            "They escape into the air as a gas.",
            "They become solid.",
            "They disappear completely.",
            "They change into oxygen."
        ],

        explanation:
            "During evaporation, water particles leave the liquid and become water vapour.",

        difficulty: 2,
        correctAnswer: "They escape into the air as a gas.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-015",
        skillId: "evaporationCondensation",
        question: "Which situation shows condensation?",
        stage: "recognise",
        options: [
            "Drops forming on a cold window",
            "A puddle drying",
            "Ice melting",
            "Butter melting"
        ],

        explanation:
            "Water vapour cools and forms liquid water on the window.",

        difficulty: 2,
        correctAnswer: "Drops forming on a cold window",
        estimatedSeconds: 20,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-016",
        skillId: "evaporationCondensation",
        question: "What can make evaporation happen faster?",
        stage: "recognise",
        options: [
            "Higher temperatures",
            "Lower temperatures",
            "Putting water in a freezer",
            "Making the water colder"
        ],

        explanation:
            "Heating gives water particles more energy to escape into the air.",

        difficulty: 2,
        correctAnswer: "Higher temperatures",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-017",
        skillId: "evaporationCondensation",
        question: "A cold bottle is taken outside on a warm day. Why do water droplets appear on it?",
        stage: "recognise",
        options: [
            "Water vapour condenses on the cold surface.",
            "Water leaks through the bottle.",
            "The bottle melts.",
            "The air freezes."
        ],

        explanation:
            "The cold surface cools the nearby water vapour, causing condensation.",

        difficulty: 2,
        correctAnswer: "Water vapour condenses on the cold surface.",
        estimatedSeconds: 20,

        tags: ["science", "condensation"]
    },

    {
        id: "sci-evap-cond-018",
        skillId: "evaporationCondensation",
        question: "Why does a puddle disappear even if it never boils?",
        stage: "recognise",
        options: [
            "Evaporation can happen below boiling point.",
            "The water becomes solid.",
            "The water is absorbed by the Sun.",
            "The puddle turns into ice."
        ],

        explanation:
            "Evaporation happens at many temperatures, not just when water boils.",

        difficulty: 2,
        correctAnswer: "Evaporation can happen below boiling point.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation"]
    },

    {
        id: "sci-evap-cond-019",
        skillId: "evaporationCondensation",
        question: "Which pair shows opposite changes of state?",
        stage: "recognise",
        options: [
            "Evaporation and condensation",
            "Melting and boiling",
            "Freezing and condensation",
            "Melting and evaporation"
        ],

        explanation:
            "One changes liquid to gas, the other changes gas to liquid.",

        difficulty: 2,
        correctAnswer: "Evaporation and condensation",
        estimatedSeconds: 20,

        tags: ["science", "states-of-matter"]
    },

    {
        id: "sci-evap-cond-020",
        skillId: "evaporationCondensation",
        question: "Which sentence best describes evaporation and condensation?",
        stage: "recognise",
        options: [
            "Evaporation changes liquids into gases, while condensation changes gases back into liquids.",
            "Both processes turn liquids into solids.",
            "Both processes need freezing temperatures.",
            "Neither process changes the state of matter."
        ],

        explanation:
            "Evaporation and condensation are opposite changes of state involving liquids and gases.",

        difficulty: 2,
        correctAnswer: "Evaporation changes liquids into gases, while condensation changes gases back into liquids.",
        estimatedSeconds: 20,

        tags: ["science", "evaporation", "condensation", "states-of-matter"]
    }

    ]

};


export default evaporationCondensation;

export {

    evaporationCondensation

};

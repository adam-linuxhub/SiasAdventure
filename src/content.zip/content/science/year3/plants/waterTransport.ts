import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const waterTransport: SkillContent = {

    skillId: "water-transport",

    title: "Water Transport in Plants",

    description:
        "Learn how water moves through a flowering plant.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

        {
            id: "sci-water-transport-001",
            skillId: "water-transport",
            question: "Where does a plant take in most of its water?",
            stage: "recognise",
            options: [
                "Through its roots",
                "Through its flowers",
                "Through its leaves",
                "Through its seeds"
            ],

            explanation:
                "Roots absorb water from the soil.",

            difficulty: 1,
            correctAnswer: "Through its roots",
            estimatedSeconds: 10,

            hint: "Think about which plant part is underground and touches the soil.",

            tags: [
                "science",
                "plants",
                "roots",
                "water"
            ]
        },

        {
            id: "sci-water-transport-002",
            skillId: "water-transport",
            question: "After the roots absorb water, which part carries it around the plant?",
            stage: "recognise",
            options: [
                "The stem",
                "The flower",
                "The seed",
                "The petals"
            ],

            explanation:
                "The stem transports water from the roots to the rest of the plant.",

            difficulty: 1,
            correctAnswer: "The stem",
            estimatedSeconds: 15,

            hint: "Look for the plant part that acts like a pathway between roots and leaves.",

            tags: [
                "science",
                "plants",
                "stem",
                "water"
            ]
        },

        {
            id: "sci-water-transport-003",
            skillId: "water-transport",
            question: "Where does most of the water carried by the stem go?",
            stage: "recognise",
            options: [
                "The leaves",
                "The roots",
                "The seeds",
                "The flowers only"
            ],

            explanation:
                "Water is carried to the leaves where it helps the plant make food.",

            difficulty: 1,
            correctAnswer: "The leaves",
            estimatedSeconds: 15,

            hint: "Think about which part needs water to make food using sunlight.",

            tags: [
                "science",
                "plants",
                "leaves",
                "water"
            ]
        },

        {
            id: "sci-water-transport-004",
            skillId: "water-transport",
            question: "Which sequence correctly shows how water travels through a plant?",
            stage: "recognise",
            options: [
                "Roots → Stem → Leaves",
                "Leaves → Stem → Roots",
                "Stem → Roots → Leaves",
                "Flowers → Stem → Roots"
            ],

            explanation:
                "Water is absorbed by the roots, carried through the stem and reaches the leaves.",

            difficulty: 1,
            correctAnswer: "Roots → Stem → Leaves",
            estimatedSeconds: 15,

            hint: "Start with the part that collects water from the soil.",

            tags: [
                "science",
                "plants",
                "water"
            ]
        },

        {
            id: "sci-water-transport-005",
            skillId: "water-transport",
            question: "Why do plants need water?",
            stage: "recognise",
            options: [
                "To help them make food and grow",
                "To make rocks",
                "To produce plastic",
                "To make soil"
            ],

            explanation:
                "Water is needed for healthy growth and for making food in the leaves.",

            difficulty: 1,
            correctAnswer: "To help them make food and grow",
            estimatedSeconds: 15,

            hint: "Plants use water as part of the process that helps them grow and stay healthy.",

            tags: [
                "science",
                "plants",
                "water"
            ]
        },

        {
            id: "sci-water-transport-006",
            skillId: "water-transport",
            question: "Which plant part absorbs water from the soil?",
            stage: "recognise",
            options: [
                "Roots",
                "Leaves",
                "Flowers",
                "Stem"
            ],

            explanation:
                "Roots absorb water and minerals from the soil.",

            difficulty: 1,
            correctAnswer: "Roots",
            estimatedSeconds: 15,

            hint: "The part that grows underground is responsible for taking in water.",

            tags: [
                "science",
                "plants",
                "roots"
            ]
        },

        {
            id: "sci-water-transport-007",
            skillId: "water-transport",
            question: "What carries water from the roots to the leaves?",
            stage: "recognise",
            options: [
                "The stem",
                "The flower",
                "The fruit",
                "The seed"
            ],

            explanation:
                "The stem transports water through the plant.",

            difficulty: 1,
            correctAnswer: "The stem",
            estimatedSeconds: 15,

            hint: "Think of the plant part that connects the underground roots to the leaves above ground.",

            tags: [
                "science",
                "plants",
                "stem"
            ]
        },

        {
            id: "sci-water-transport-008",
            skillId: "water-transport",
            question: "Which part uses the water to help make food?",
            stage: "recognise",
            options: [
                "Leaves",
                "Roots",
                "Seeds",
                "Flowers"
            ],

            explanation:
                "Leaves use water together with sunlight and carbon dioxide to make food.",

            difficulty: 1,
            correctAnswer: "Leaves",
            estimatedSeconds: 15,

            hint: "The plant part that catches sunlight is also where food is made.",

            tags: [
                "science",
                "plants",
                "leaves"
            ]
        },

        {
            id: "sci-water-transport-009",
            skillId: "water-transport",
            question: "If roots cannot absorb enough water, what is most likely to happen?",
            stage: "recognise",
            options: [
                "The plant may wilt.",
                "The plant grows faster.",
                "The plant makes more seeds immediately.",
                "Nothing changes."
            ],

            explanation:
                "Without enough water, plants become weak and may wilt.",

            difficulty: 1,
            correctAnswer: "The plant may wilt.",
            estimatedSeconds: 15,

            hint: "Plants need water to stay firm and healthy. Think about what happens when they lose water.",

            tags: [
                "science",
                "plants",
                "water"
            ]
        },

        {
            id: "sci-water-transport-010",
            skillId: "water-transport",
            question: "Which statement is correct?",
            stage: "recognise",
            options: [
                "Roots absorb water and the stem carries it to the leaves.",
                "Leaves absorb water and send it to the roots.",
                "Flowers carry water around the plant.",
                "Seeds absorb water for the whole plant."
            ],

            explanation:
                "Water moves from the roots, through the stem and to the leaves.",

            difficulty: 1,
            correctAnswer: "Roots absorb water and the stem carries it to the leaves.",
            estimatedSeconds: 20,

            hint: "Remember the journey of water: it starts underground and travels upwards.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-011",
            skillId: "water-transport",
            question: "Which part of a plant is the main entry point for water from the soil?",
            stage: "recognise",
            options: [
                "Roots",
                "Flowers",
                "Leaves",
                "Fruit"
            ],

            explanation:
                "Roots take in water from the soil and begin its journey through the plant.",

            difficulty: 1,
            correctAnswer: "Roots",
            estimatedSeconds: 15,

            hint: "Look underground for the part that is in contact with the soil.",

            tags: [
                "science",
                "plants",
                "roots",
                "water"
            ]
        },

        {
            id: "sci-water-transport-012",
            skillId: "water-transport",
            question: "After water enters the roots, what happens next?",
            stage: "recognise",
            options: [
                "It moves through the stem.",
                "It turns into a seed.",
                "It leaves through a flower.",
                "It stays underground."
            ],

            explanation:
                "After entering through the roots, water is transported through the stem.",

            difficulty: 1,
            correctAnswer: "It moves through the stem.",
            estimatedSeconds: 15,

            hint: "Think about the pathway that carries water upwards.",

            tags: [
                "science",
                "plants",
                "roots",
                "stem",
                "water"
            ]
        },

        {
            id: "sci-water-transport-013",
            skillId: "water-transport",
            question: "Which part of a plant receives water after it travels up the stem?",
            stage: "recognise",
            options: [
                "Leaves",
                "Roots",
                "Seeds",
                "Soil"
            ],

            explanation:
                "Water travels through the stem to the leaves, where it is used to help make food.",

            difficulty: 1,
            correctAnswer: "Leaves",
            estimatedSeconds: 15,

            hint: "Think about the part above the stem that uses sunlight to make food.",

            tags: [
                "science",
                "plants",
                "leaves",
                "water"
            ]
        },

        {
            id: "sci-water-transport-014",
            skillId: "water-transport",
            question: "Which route shows water moving through a plant?",
            stage: "recognise",
            options: [
                "Roots → Stem → Leaves",
                "Leaves → Roots → Stem",
                "Flowers → Leaves → Roots",
                "Seeds → Flowers → Stem"
            ],

            explanation:
                "Water enters through the roots, travels up the stem and reaches the leaves.",

            difficulty: 1,
            correctAnswer: "Roots → Stem → Leaves",
            estimatedSeconds: 15,

            hint: "Start where water enters the plant and follow it upwards.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },
                {
            id: "sci-water-transport-015",
            skillId: "water-transport",
            question: "Which sequence shows the correct journey of water?",
            stage: "recognise",
            options: [
                "Soil → Roots → Stem → Leaves",
                "Leaves → Stem → Soil → Roots",
                "Roots → Leaves → Soil → Stem",
                "Stem → Soil → Roots → Leaves"
            ],

            explanation:
                "Water is absorbed from the soil by the roots, travels through the stem and reaches the leaves.",

            difficulty: 2,
            correctAnswer: "Soil → Roots → Stem → Leaves",
            estimatedSeconds: 20,

            hint: "Start with where the water comes from before it enters the plant.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-016",
            skillId: "water-transport",
            question: "What do roots absorb besides water?",
            stage: "recognise",
            options: [
                "Minerals",
                "Sunlight",
                "Clouds",
                "Seeds"
            ],

            explanation:
                "Roots absorb both water and minerals from the soil.",

            difficulty: 2,
            correctAnswer: "Minerals",
            estimatedSeconds: 20,

            hint: "Plants need more than just water from the soil. Think about nutrients that help them grow.",

            tags: [
                "science",
                "plants",
                "roots",
                "minerals"
            ]
        },

        {
            id: "sci-water-transport-017",
            skillId: "water-transport",
            question: "Which part transports water to every part of the plant?",
            stage: "recognise",
            options: [
                "Stem",
                "Flower",
                "Leaf",
                "Seed"
            ],

            explanation:
                "The stem carries water from the roots throughout the plant.",

            difficulty: 2,
            correctAnswer: "Stem",
            estimatedSeconds: 20,

            hint: "Look for the plant part that connects the roots with the rest of the plant.",

            tags: [
                "science",
                "plants",
                "stem",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-018",
            skillId: "water-transport",
            question: "A plant is watered. Which part receives the water first?",
            stage: "recognise",
            options: [
                "Roots",
                "Leaves",
                "Flowers",
                "Stem"
            ],

            explanation:
                "The roots are the first part of the plant to absorb water from the soil.",

            difficulty: 2,
            correctAnswer: "Roots",
            estimatedSeconds: 20,

            hint: "Water enters the plant where the plant touches the soil.",

            tags: [
                "science",
                "plants",
                "roots"
            ]
        },

        {
            id: "sci-water-transport-019",
            skillId: "water-transport",
            question: "Which statement is true?",
            stage: "recognise",
            options: [
                "Water moves upwards through the stem.",
                "Water moves from the leaves into the soil.",
                "Flowers absorb all the water.",
                "Seeds carry water around the plant."
            ],

            explanation:
                "Water travels upwards through the stem from the roots to the leaves.",

            difficulty: 2,
            correctAnswer: "Water moves upwards through the stem.",
            estimatedSeconds: 20,

            hint: "Think about the direction water must travel to reach leaves above the ground.",

            tags: [
                "science",
                "plants",
                "stem",
                "water"
            ]
        },

        {
            id: "sci-water-transport-020",
            skillId: "water-transport",
            question: "What is the main job of the stem in water transport?",
            stage: "recognise",
            options: [
                "To carry water from the roots to the leaves",
                "To absorb water from the soil",
                "To make food",
                "To produce seeds"
            ],

            explanation:
                "The stem transports water throughout the plant.",

            difficulty: 2,
            correctAnswer: "To carry water from the roots to the leaves",
            estimatedSeconds: 20,

            hint: "The stem does not collect water; it moves water to where it is needed.",

            tags: [
                "science",
                "plants",
                "stem",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-021",
            skillId: "water-transport",
            question: "A plant has healthy roots but a damaged stem. What is most likely to happen?",
            stage: "recognise",
            options: [
                "Water will not reach the leaves properly.",
                "The roots will stop absorbing water.",
                "The flowers will absorb water instead.",
                "Nothing will change."
            ],

            explanation:
                "The stem is needed to carry water from the roots to the leaves.",

            difficulty: 3,
            correctAnswer: "Water will not reach the leaves properly.",
            estimatedSeconds: 25,

            hint: "If the transport pathway is damaged, think about which parts will stop receiving water.",

            tags: [
                "science",
                "plants",
                "stem",
                "water"
            ]
        },

        {
            id: "sci-water-transport-022",
            skillId: "water-transport",
            question: "Why must water reach the leaves?",
            stage: "recognise",
            options: [
                "The leaves use it to make food.",
                "The leaves turn it into roots.",
                "The leaves store all the water forever.",
                "The leaves make flowers from it."
            ],

            explanation:
                "Leaves need water for photosynthesis, which makes food for the plant.",

            difficulty: 3,
            correctAnswer: "The leaves use it to make food.",
            estimatedSeconds: 25,

            hint: "Leaves are the part of the plant that uses sunlight to create food.",

            tags: [
                "science",
                "plants",
                "leaves",
                "water"
            ]
        },

        {
            id: "sci-water-transport-023",
            skillId: "water-transport",
            question: "Which plant would most likely wilt first?",
            stage: "recognise",
            options: [
                "A plant that cannot absorb water through its roots",
                "A plant in healthy soil",
                "A plant with strong roots and stem",
                "A well-watered plant"
            ],

            explanation:
                "Without water entering through the roots, the whole plant can wilt.",

            difficulty: 3,
            correctAnswer: "A plant that cannot absorb water through its roots",
            estimatedSeconds: 25,

            hint: "A plant cannot stay healthy without a way to take in water.",

            tags: [
                "science",
                "plants",
                "roots",
                "water"
            ]
        },

        {
            id: "sci-water-transport-024",
            skillId: "water-transport",
            question: "Which sequence correctly describes water transport?",
            stage: "recognise",
            options: [
                "Roots absorb → Stem carries → Leaves use",
                "Leaves absorb → Roots carry → Flowers use",
                "Stem absorbs → Flowers carry → Roots use",
                "Flowers absorb → Leaves carry → Seeds use"
            ],

            explanation:
                "Roots absorb water, the stem transports it and the leaves use it.",

            difficulty: 3,
            correctAnswer: "Roots absorb → Stem carries → Leaves use",
            estimatedSeconds: 25,

            hint: "Remember the three main steps: taking in water, moving it, then using it.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-025",
            skillId: "water-transport",
            question: "Why is water transport important?",
            stage: "recognise",
            options: [
                "It helps every part of the plant receive the water it needs.",
                "It changes leaves into flowers.",
                "It helps plants produce rocks.",
                "It stops roots from growing."
            ],

            explanation:
                "Transporting water allows the plant to grow, make food and stay healthy.",

            difficulty: 3,
            correctAnswer: "It helps every part of the plant receive the water it needs.",
            estimatedSeconds: 25,

            hint: "Think about why water needs to travel beyond just the roots.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-026",
            skillId: "water-transport",
            question: "A plant has been watered. Which part carries the water upwards?",
            stage: "recognise",
            options: [
                "The stem",
                "The flower",
                "The fruit",
                "The seed"
            ],

            explanation:
                "The stem transports water from the roots to the leaves and other parts of the plant.",

            difficulty: 3,
            correctAnswer: "The stem",
            estimatedSeconds: 25,

            hint: "The part that holds leaves above the ground also acts as a transport route.",

            tags: [
                "science",
                "plants",
                "stem",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-027",
            skillId: "water-transport",
            question: "Why do roots need to be in the soil?",
            stage: "recognise",
            options: [
                "To absorb water and minerals",
                "To catch sunlight",
                "To produce flowers",
                "To make seeds"
            ],

            explanation:
                "Roots grow in the soil so they can absorb water and minerals needed by the plant.",

            difficulty: 3,
            correctAnswer: "To absorb water and minerals",
            estimatedSeconds: 25,

            hint: "Roots are underground because the soil contains the resources the plant needs.",

            tags: [
                "science",
                "plants",
                "roots",
                "minerals"
            ]
        },

        {
            id: "sci-water-transport-028",
            skillId: "water-transport",
            question: "If water cannot reach the leaves, what is most likely to happen?",
            stage: "recognise",
            options: [
                "The plant will struggle to make food.",
                "The flowers will become roots.",
                "The stem will turn into soil.",
                "The seeds will grow immediately."
            ],

            explanation:
                "Leaves need water to make food, so the plant will not grow well without it.",

            difficulty: 3,
            correctAnswer: "The plant will struggle to make food.",
            estimatedSeconds: 25,

            hint: "Leaves need water for photosynthesis. Think about what happens if they cannot get it.",

            tags: [
                "science",
                "plants",
                "leaves",
                "water"
            ]
        },
                {
            id: "sci-water-transport-029",
            skillId: "water-transport",
            question: "What helps keep a plant healthy by supplying water to all its parts?",
            stage: "recognise",
            options: [
                "Water transport",
                "Flower colour",
                "Seed shape",
                "Petal size"
            ],

            explanation:
                "Water transport ensures every part of the plant receives the water it needs.",

            difficulty: 3,
            correctAnswer: "Water transport",
            estimatedSeconds: 25,

            hint: "Think about the process that moves water from the roots to other parts of the plant.",

            tags: [
                "science",
                "plants",
                "transport",
                "water"
            ]
        },

        {
            id: "sci-water-transport-030",
            skillId: "water-transport",
            question: "Which part of the plant uses water together with sunlight to make food?",
            stage: "recognise",
            options: [
                "Leaves",
                "Roots",
                "Stem",
                "Flowers"
            ],

            explanation:
                "Leaves use water, sunlight and carbon dioxide during photosynthesis.",

            difficulty: 3,
            correctAnswer: "Leaves",
            estimatedSeconds: 25,

            hint: "Which plant part captures sunlight and makes food?",

            tags: [
                "science",
                "plants",
                "leaves",
                "photosynthesis"
            ]
        },

        {
            id: "sci-water-transport-031",
            skillId: "water-transport",
            question: "Which statement best describes the job of the roots?",
            stage: "recognise",
            options: [
                "They absorb water and minerals from the soil.",
                "They make food using sunlight.",
                "They carry water around the plant.",
                "They produce seeds."
            ],

            explanation:
                "Roots absorb water and minerals before they are carried through the stem.",

            difficulty: 4,
            correctAnswer: "They absorb water and minerals from the soil.",
            estimatedSeconds: 30,

            hint: "Roots are underground because they collect important resources from the soil.",

            tags: [
                "science",
                "plants",
                "roots",
                "minerals"
            ]
        },

        {
            id: "sci-water-transport-032",
            skillId: "water-transport",
            question: "A plant is growing well. Which sequence is most likely happening?",
            stage: "recognise",
            options: [
                "Roots absorb → Stem carries → Leaves use",
                "Leaves absorb → Flowers carry → Roots use",
                "Flowers absorb → Stem carries → Seeds use",
                "Seeds absorb → Roots carry → Leaves use"
            ],

            explanation:
                "Healthy plants rely on water moving from the roots, through the stem and into the leaves.",

            difficulty: 4,
            correctAnswer: "Roots absorb → Stem carries → Leaves use",
            estimatedSeconds: 30,

            hint: "Follow the path water takes from entering the plant to where it is used.",

            tags: [
                "science",
                "plants",
                "transport",
                "water"
            ]
        },

        {
            id: "sci-water-transport-033",
            skillId: "water-transport",
            question: "Which part would stop working properly first if the roots dried out?",
            stage: "recognise",
            options: [
                "The leaves",
                "The petals",
                "The seeds",
                "The fruit"
            ],

            explanation:
                "Without water from the roots, the leaves cannot continue making food effectively.",

            difficulty: 4,
            correctAnswer: "The leaves",
            estimatedSeconds: 30,

            hint: "Which part depends on water to make food for the plant?",

            tags: [
                "science",
                "plants",
                "roots",
                "leaves"
            ]
        },

        {
            id: "sci-water-transport-034",
            skillId: "water-transport",
            question: "Why is the stem important as well as the roots?",
            stage: "recognise",
            options: [
                "It carries water to the rest of the plant.",
                "It absorbs water from the air.",
                "It makes all the food.",
                "It produces seeds."
            ],

            explanation:
                "After the roots absorb water, the stem transports it throughout the plant.",

            difficulty: 4,
            correctAnswer: "It carries water to the rest of the plant.",
            estimatedSeconds: 30,

            hint: "The roots collect water, but another part must move it around the plant.",

            tags: [
                "science",
                "plants",
                "stem",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-035",
            skillId: "water-transport",
            question: "A plant has healthy leaves but damaged roots. What is the most likely result?",
            stage: "recognise",
            options: [
                "The leaves will eventually stop receiving enough water.",
                "The leaves will absorb water from sunlight.",
                "The flowers will replace the roots.",
                "Nothing will change."
            ],

            explanation:
                "Healthy leaves still depend on the roots to supply water.",

            difficulty: 4,
            correctAnswer: "The leaves will eventually stop receiving enough water.",
            estimatedSeconds: 30,

            hint: "Healthy leaves cannot work properly if the part that collects water is damaged.",

            tags: [
                "science",
                "plants",
                "roots",
                "water"
            ]
        },

        {
            id: "sci-water-transport-036",
            skillId: "water-transport",
            question: "Why do plants need a continuous supply of water?",
            stage: "recognise",
            options: [
                "To keep making food and growing.",
                "To change leaves into flowers.",
                "To make the stem shorter.",
                "To stop roots growing."
            ],

            explanation:
                "Plants constantly need water for healthy growth and photosynthesis.",

            difficulty: 4,
            correctAnswer: "To keep making food and growing.",
            estimatedSeconds: 30,

            hint: "Plants are living things that need water for important processes every day.",

            tags: [
                "science",
                "plants",
                "water",
                "growth"
            ]
        },

        {
            id: "sci-water-transport-037",
            skillId: "water-transport",
            question: "Which of these is NOT part of the normal path water takes through a plant?",
            stage: "recognise",
            options: [
                "Seeds",
                "Roots",
                "Stem",
                "Leaves"
            ],

            explanation:
                "Water mainly travels from the roots through the stem to the leaves.",

            difficulty: 4,
            correctAnswer: "Seeds",
            estimatedSeconds: 30,

            hint: "Think about the route water takes through the main transport system of a plant.",

            tags: [
                "science",
                "plants",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-038",
            skillId: "water-transport",
            question: "What happens to water after it is absorbed by the roots?",
            stage: "recognise",
            options: [
                "It travels upwards through the stem.",
                "It stays in the roots forever.",
                "It turns into soil.",
                "It leaves the plant immediately."
            ],

            explanation:
                "The stem carries absorbed water upwards to the leaves and other parts of the plant.",

            difficulty: 4,
            correctAnswer: "It travels upwards through the stem.",
            estimatedSeconds: 30,

            hint: "Water must move away from the roots so the rest of the plant can use it.",

            tags: [
                "science",
                "plants",
                "stem",
                "water"
            ]
        },

        {
            id: "sci-water-transport-039",
            skillId: "water-transport",
            question: "Which plant would probably stay healthiest?",
            stage: "recognise",
            options: [
                "A plant with healthy roots, stem and leaves",
                "A plant with no roots",
                "A plant with a broken stem",
                "A plant that never receives water"
            ],

            explanation:
                "All parts of the water transport system need to work together for healthy growth.",

            difficulty: 4,
            correctAnswer: "A plant with healthy roots, stem and leaves",
            estimatedSeconds: 30,

            hint: "A healthy plant needs every part of the water transport system working together.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-040",
            skillId: "water-transport",
            question: "Which sentence best explains water transport in plants?",
            stage: "recognise",
            options: [
                "Roots absorb water, the stem carries it and the leaves use it.",
                "Leaves absorb water and flowers carry it.",
                "Flowers absorb water and roots use it.",
                "Seeds absorb water and stems make food."
            ],

            explanation:
                "This describes the correct route water takes through a flowering plant.",

            difficulty: 4,
            correctAnswer: "Roots absorb water, the stem carries it and the leaves use it.",
            estimatedSeconds: 30,

            hint: "Follow the journey of water from where it enters the plant to where it is used.",

            tags: [
                "science",
                "plants",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-041",
            skillId: "water-transport",
            question: "A plant's roots are healthy, but its stem is blocked. What is most likely to happen?",
            stage: "recognise",
            options: [
                "Water will not reach the leaves properly.",
                "The roots will stop absorbing water.",
                "The flowers will absorb water instead.",
                "The plant will grow faster."
            ],

            explanation:
                "The stem carries water from the roots to the leaves. If it is blocked, water cannot travel properly.",

            difficulty: 5,
            correctAnswer: "Water will not reach the leaves properly.",
            estimatedSeconds: 35,

            hint: "The roots collect water, but another part must transport it around the plant.",

            tags: [
                "science",
                "plants",
                "stem",
                "water",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-042",
            skillId: "water-transport",
            question: "Which plant is most likely to make food successfully?",
            stage: "recognise",
            options: [
                "A plant whose roots, stem and leaves are all healthy",
                "A plant with broken roots",
                "A plant with no leaves",
                "A plant with a damaged stem"
            ],

            explanation:
                "Plants need healthy roots to absorb water, a healthy stem to transport it and healthy leaves to make food.",

            difficulty: 5,
            correctAnswer: "A plant whose roots, stem and leaves are all healthy",
            estimatedSeconds: 35,

            hint: "Making food needs water transport and healthy leaves working together.",

            tags: [
                "science",
                "plants",
                "water",
                "photosynthesis"
            ]
        },

        {
            id: "sci-water-transport-043",
            skillId: "water-transport",
            question: "Why is water carried to every part of a plant?",
            stage: "recognise",
            options: [
                "Every part needs water to stay healthy and grow.",
                "Water only changes the colour of leaves.",
                "Only flowers need water.",
                "Water is stored only in the stem."
            ],

            explanation:
                "Water is needed throughout the plant for growth and healthy cells.",

            difficulty: 5,
            correctAnswer: "Every part needs water to stay healthy and grow.",
            estimatedSeconds: 35,

            hint: "Plants are living things, so think about what every living part needs.",

            tags: [
                "science",
                "plants",
                "water",
                "growth"
            ]
        },

        {
            id: "sci-water-transport-044",
            skillId: "water-transport",
            question: "What would happen if a plant could not absorb minerals from the soil?",
            stage: "recognise",
            options: [
                "It would not grow as well.",
                "It would grow much faster.",
                "It would no longer need water.",
                "Nothing would change."
            ],

            explanation:
                "Plants need both water and minerals from the soil for healthy growth.",

            difficulty: 5,
            correctAnswer: "It would not grow as well.",
            estimatedSeconds: 35,

            hint: "Roots collect more than just water. Think about the other useful materials plants need.",

            tags: [
                "science",
                "plants",
                "minerals",
                "roots"
            ]
        },

        {
            id: "sci-water-transport-045",
            skillId: "water-transport",
            question: "Which statement best explains why stems are important?",
            stage: "recognise",
            options: [
                "They transport water from the roots to the rest of the plant.",
                "They absorb water from the soil.",
                "They make all of the plant's food.",
                "They produce all the seeds."
            ],

            explanation:
                "The stem is the plant's transport pathway for water.",

            difficulty: 5,
            correctAnswer: "They transport water from the roots to the rest of the plant.",
            estimatedSeconds: 35,

            hint: "The stem acts like a pathway connecting the parts of the plant.",

            tags: [
                "science",
                "plants",
                "stem",
                "transport"
            ]
        },

        {
            id: "sci-water-transport-046",
            skillId: "water-transport",
            question: "A gardener forgets to water a plant for many days. Which part is affected first?",
            stage: "recognise",
            options: [
                "The roots cannot absorb enough water.",
                "The flowers make extra water.",
                "The stem grows taller.",
                "The leaves produce more water."
            ],

            explanation:
                "Without water in the soil, the roots cannot absorb enough to supply the plant.",

            difficulty: 5,
            correctAnswer: "The roots cannot absorb enough water.",
            estimatedSeconds: 35,

            hint: "Before water can move through a plant, it must first enter somewhere.",

            tags: [
                "science",
                "plants",
                "roots",
                "water"
            ]
        },

        {
            id: "sci-water-transport-047",
            skillId: "water-transport",
            question: "Which sentence correctly describes the movement of water?",
            stage: "recognise",
            options: [
                "Water moves from the soil into the roots, through the stem and to the leaves.",
                "Water moves from the leaves into the roots.",
                "Water moves from flowers into the stem.",
                "Water moves from seeds into the roots."
            ],

            explanation:
                "This is the correct pathway of water through a flowering plant.",

            difficulty: 5,
            correctAnswer: "Water moves from the soil into the roots, through the stem and to the leaves.",
            estimatedSeconds: 35,

            hint: "Start at the place where water enters the plant and follow the route upwards.",

            tags: [
                "science",
                "plants",
                "transport",
                "water"
            ]
        },

        {
            id: "sci-water-transport-048",
            skillId: "water-transport",
            question: "Why is water transport essential for a flowering plant?",
            stage: "recognise",
            options: [
                "It allows water to reach the leaves so the plant can make food and grow.",
                "It changes flowers into fruit.",
                "It helps roots make sunlight.",
                "It stops the plant producing seeds."
            ],

            explanation:
                "Without water transport, leaves cannot make enough food and the plant cannot grow properly.",

            difficulty: 5,
            correctAnswer: "It allows water to reach the leaves so the plant can make food and grow.",
            estimatedSeconds: 35,

            hint: "Think about why leaves need a supply of water.",

            tags: [
                "science",
                "plants",
                "transport",
                "growth"
            ]
        },

        {
            id: "sci-water-transport-049",
            skillId: "water-transport",
            question: "Which group of plant parts works together to move water around the plant?",
            stage: "recognise",
            options: [
                "Roots, stem and leaves",
                "Flowers, petals and fruit",
                "Seeds, flowers and petals",
                "Fruit, seeds and roots"
            ],

            explanation:
                "Roots absorb water, the stem transports it and the leaves use it.",

            difficulty: 5,
            correctAnswer: "Roots, stem and leaves",
            estimatedSeconds: 35,

            hint: "Choose the group that includes the part that collects water, moves it and uses it.",

            tags: [
                "science",
                "plants",
                "transport",
                "water"
            ]
        },

        {
            id: "sci-water-transport-050",
            skillId: "water-transport",
            question: "Which summary best describes water transport in plants?",
            stage: "recognise",
            options: [
                "Roots absorb water and minerals, the stem carries them to the leaves where they help the plant make food and grow.",
                "Leaves absorb water and send it to the roots.",
                "Flowers collect water for the whole plant.",
                "Seeds carry water through the stem."
            ],

            explanation:
                "Water transport begins in the roots, continues through the stem and supports the leaves in making food and keeping the plant healthy.",

            difficulty: 5,
            correctAnswer: "Roots absorb water and minerals, the stem carries them to the leaves where they help the plant make food and grow.",
            estimatedSeconds: 40,

            hint: "Pick the option that describes the complete journey of water and why the plant needs it.",

            tags: [
                "science",
                "plants",
                "water",
                "transport",
                "roots",
                "stem",
                "leaves"
            ]
        }

    ]

};

export default waterTransport;

export {
    waterTransport
};
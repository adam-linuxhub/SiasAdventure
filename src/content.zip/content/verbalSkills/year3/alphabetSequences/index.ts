/*==================================================
  GENERATED FILE

  DO NOT EDIT MANUALLY

==================================================*/

export { default } from "./alphabetSequences1";

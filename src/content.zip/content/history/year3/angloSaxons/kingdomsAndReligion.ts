import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const kingdomsAndReligion: SkillContent = {

    skillId: "kingdomsAndReligion",

    title: "Anglo-Saxon Kingdoms and Religion",

    description:
        "Learn about Anglo-Saxon kingdoms, kings, Christianity and the importance of monasteries.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "hist-asr-001",
        skillId: "kingdomsAndReligion",
        question:
            "What were Anglo-Saxon kingdoms?",
        stage: "recognise",
        options: [
            "Areas of Britain ruled by different kings",
            "Roman buildings",
            "Types of farming tools",
            "Places outside Britain only"
        ],

        hint: "Imagine Britain split into lands with different rulers.",
        explanation:
            "After settling in Britain, Anglo-Saxons formed different kingdoms ruled by kings.",

        difficulty: 1,
        correctAnswer: "Areas of Britain ruled by different kings",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-002",
        skillId: "kingdomsAndReligion",
        question:
            "What was the leader of an Anglo-Saxon kingdom called?",
        stage: "recognise",
        options: [
            "A king",
            "A pharaoh",
            "A senator",
            "A president"
        ],

        hint: "Think about who leads a country rather than a group.",
        explanation:
            "Anglo-Saxon kingdoms were ruled by kings.",

        difficulty: 1,
        correctAnswer: "A king",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-003",
        skillId: "kingdomsAndReligion",
        question:
            "Which was an Anglo-Saxon kingdom?",
        stage: "recognise",
        options: [
            "Mercia",
            "Rome",
            "Egypt",
            "Greece"
        ],

        hint: "Choose the place that existed in Anglo-Saxon England.",
        explanation:
            "Mercia was one of the important Anglo-Saxon kingdoms.",

        difficulty: 1,
        correctAnswer: "Mercia",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-004",
        skillId: "kingdomsAndReligion",
        question:
            "Which other Anglo-Saxon kingdom existed?",
        stage: "recognise",
        options: [
            "Wessex",
            "The Roman Empire",
            "The Viking Empire",
            "Ancient Egypt"
        ],

        hint: "Look for another historic English kingdom.",
        explanation:
            "Wessex was one of the Anglo-Saxon kingdoms.",

        difficulty: 1,
        correctAnswer: "Wessex",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-005",
        skillId: "kingdomsAndReligion",
        question:
            "What did Anglo-Saxon kings do?",
        stage: "recognise",
        options: [
            "They ruled their kingdoms and made decisions",
            "They only farmed",
            "They built pyramids",
            "They controlled Rome"
        ],

        hint: "A ruler's main job was leadership, not manual work.",
        explanation:
            "Kings made laws and led their kingdoms.",

        difficulty: 1,
        correctAnswer: "They ruled their kingdoms and made decisions",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-006",
        skillId: "kingdomsAndReligion",
        question:
            "What religion did many Anglo-Saxons follow at first?",
        stage: "recognise",
        options: [
            "Pagan beliefs",
            "Christianity only",
            "Ancient Egyptian religion",
            "Roman religion only"
        ],

        hint: "Consider beliefs before widespread Christian worship.",
        explanation:
            "Early Anglo-Saxons followed pagan beliefs before many converted to Christianity.",

        difficulty: 1,
        correctAnswer: "Pagan beliefs",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-007",
        skillId: "kingdomsAndReligion",
        question:
            "What religion became important in Anglo-Saxon England?",
        stage: "recognise",
        options: [
            "Christianity",
            "Ancient Egyptian religion",
            "Greek mythology",
            "Roman emperor worship"
        ],

        hint: "Which faith spread across England over time?",
        explanation:
            "Christianity spread through Anglo-Saxon kingdoms.",

        difficulty: 1,
        correctAnswer: "Christianity",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-008",
        skillId: "kingdomsAndReligion",
        question:
            "Who helped spread Christianity in Anglo-Saxon England?",
        stage: "recognise",
        options: [
            "Missionaries",
            "Roman soldiers",
            "Vikings",
            "Pharaohs"
        ],

        hint: "Who travels to teach new beliefs?",
        explanation:
            "Missionaries travelled to teach people about Christianity.",

        difficulty: 1,
        correctAnswer: "Missionaries",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-009",
        skillId: "kingdomsAndReligion",
        question:
            "What was a monastery?",
        stage: "recognise",
        options: [
            "A place where monks lived and worked",
            "A Roman fort",
            "A farming machine",
            "A royal palace"
        ],

        hint: "Think of a community where monks lived together.",
        explanation:
            "Monasteries were religious communities where monks lived.",

        difficulty: 1,
        correctAnswer: "A place where monks lived and worked",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-010",
        skillId: "kingdomsAndReligion",
        question:
            "Why were monasteries important?",
        stage: "recognise",
        options: [
            "They were centres for learning and writing",
            "They were only used for battles",
            "They replaced farms",
            "They were Roman towns"
        ],

        hint: "Knowledge was carefully copied before printing existed.",
        explanation:
            "Monasteries preserved knowledge and produced written records.",

        difficulty: 1,
        correctAnswer: "They were centres for learning and writing",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-011",
        skillId: "kingdomsAndReligion",
        question:
            "Who was Alfred the Great?",
        stage: "recognise",
        options: [
            "An Anglo-Saxon king",
            "A Roman emperor",
            "A Viking warrior",
            "An Egyptian pharaoh"
        ],

        hint: "Remember the famous ruler of Wessex.",
        explanation:
            "Alfred the Great was an important Anglo-Saxon king of Wessex.",

        difficulty: 1,
        correctAnswer: "An Anglo-Saxon king",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kings"]
    },

    {
        id: "hist-asr-012",
        skillId: "kingdomsAndReligion",
        question:
            "Why is Alfred the Great remembered?",
        stage: "recognise",
        options: [
            "He defended his kingdom and encouraged learning",
            "He built pyramids",
            "He ruled Rome",
            "He discovered America"
        ],

        hint: "Think about why some rulers earn the title 'Great'.",
        explanation:
            "Alfred helped protect Wessex and supported education.",

        difficulty: 2,
        correctAnswer: "He defended his kingdom and encouraged learning",
        estimatedSeconds: 25,

        tags: ["history", "year3", "anglo-saxons", "kings"]
    },

    {
        id: "hist-asr-013",
        skillId: "kingdomsAndReligion",
        question:
            "What did monks often do?",
        stage: "recognise",
        options: [
            "Write books and study",
            "Drive cars",
            "Build computers",
            "Fly planes"
        ],

        hint: "Books were copied by hand in monasteries.",
        explanation:
            "Monks copied texts and helped preserve knowledge.",

        difficulty: 1,
        correctAnswer: "Write books and study",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-014",
        skillId: "kingdomsAndReligion",
        question:
            "Why are written records important to historians?",
        stage: "recognise",
        options: [
            "They provide information about the past",
            "They predict the future",
            "They replace all evidence",
            "They show modern life"
        ],

        hint: "Written evidence helps us learn about earlier times.",
        explanation:
            "Written records help historians understand past events.",

        difficulty: 2,
        correctAnswer: "They provide information about the past",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons"]
    },

    {
        id: "hist-asr-015",
        skillId: "kingdomsAndReligion",
        question:
            "What happened when Christianity spread?",
        stage: "recognise",
        options: [
            "Many people changed their beliefs",
            "All kingdoms disappeared",
            "The Romans returned",
            "Farming stopped"
        ],

        hint: "New beliefs changed how many people lived.",
        explanation:
            "Christianity changed beliefs and influenced Anglo-Saxon society.",

        difficulty: 2,
        correctAnswer: "Many people changed their beliefs",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-016",
        skillId: "kingdomsAndReligion",
        question:
            "Why were kings important in Anglo-Saxon society?",
        stage: "recognise",
        options: [
            "They made decisions and protected their kingdoms",
            "They only worked as farmers",
            "They had no power",
            "They avoided leadership"
        ],

        hint: "A kingdom needed leadership and protection.",
        explanation:
            "Kings led their people and controlled kingdoms.",

        difficulty: 2,
        correctAnswer: "They made decisions and protected their kingdoms",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-017",
        skillId: "kingdomsAndReligion",
        question:
            "What evidence can tell us about Anglo-Saxon religion?",
        stage: "recognise",
        options: [
            "Churches, objects and written records",
            "Modern buildings only",
            "Computer games",
            "Future inventions"
        ],

        hint: "Historians compare different kinds of surviving evidence.",
        explanation:
            "Historians use evidence to understand beliefs in the past.",

        difficulty: 2,
        correctAnswer: "Churches, objects and written records",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-018",
        skillId: "kingdomsAndReligion",
        question:
            "What was one role of monasteries?",
        stage: "recognise",
        options: [
            "Teaching and preserving knowledge",
            "Building Roman armies",
            "Running airports",
            "Creating machines"
        ],

        hint: "Learning was one of a monastery's key purposes.",
        explanation:
            "Monasteries became important places of learning.",

        difficulty: 2,
        correctAnswer: "Teaching and preserving knowledge",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "religion"]
    },

    {
        id: "hist-asr-019",
        skillId: "kingdomsAndReligion",
        question:
            "Why do we study Anglo-Saxon kingdoms?",
        stage: "recognise",
        options: [
            "To understand how Britain was ruled in the past",
            "To create new kingdoms",
            "To replace history",
            "To predict future kings"
        ],

        hint: "Studying the past explains today's Britain.",
        explanation:
            "Studying kingdoms helps us understand past societies.",

        difficulty: 2,
        correctAnswer: "To understand how Britain was ruled in the past",
        estimatedSeconds: 20,

        tags: ["history", "year3", "anglo-saxons", "kingdoms"]
    },

    {
        id: "hist-asr-020",
        skillId: "kingdomsAndReligion",
        question:
            "Which sentence best describes Anglo-Saxon kingdoms and religion?",
        stage: "recognise",
        options: [
            "Kings ruled kingdoms and Christianity became an important influence",
            "There were no leaders or beliefs",
            "The Romans controlled everything",
            "Religion had no effect"
        ],

        hint: "Combine the ideas of leadership and religion.",
        explanation:
            "Kings and religion were important parts of Anglo-Saxon society.",

        difficulty: 2,
        correctAnswer: "Kings ruled kingdoms and Christianity became an important influence",
        estimatedSeconds: 25,

        tags: ["history", "year3", "anglo-saxons"]
    }

    ]

};


export default kingdomsAndReligion;

export {

    kingdomsAndReligion

};

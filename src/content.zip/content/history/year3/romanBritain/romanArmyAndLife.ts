import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const romanArmyAndLife: SkillContent = {

    skillId: "romanArmyAndLife",

    title: "The Roman Army and Life in Roman Britain",

    description:
        "Learn about Roman soldiers, the organisation of the army and how Roman rule changed life in Britain.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "hist-ral-001",
        skillId: "romanArmyAndLife",
        question:
            "What was a Roman soldier called?",
        stage: "recognise",
        options: [
            "A legionary",
            "A pharaoh",
            "A knight",
            "A scribe"
        ],

        hint: "Think about what material gave this period of history its name.",

        explanation:
            "A Roman soldier who served in a legion was called a legionary.",

        difficulty: 1,
        correctAnswer: "A legionary",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-002",
        skillId: "romanArmyAndLife",
        question:
            "What was the Roman army known for?",
        stage: "recognise",
        options: [
            "Being organised and disciplined",
            "Avoiding training",
            "Having no leaders",
            "Using modern machines"
        ],

        hint: "Ignore modern materials and choose the natural one used most often.",

        explanation:
            "The Roman army was successful because soldiers were well trained and organised.",

        difficulty: 1,
        correctAnswer: "Being organised and disciplined",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-003",
        skillId: "romanArmyAndLife",
        question:
            "What was a group of Roman soldiers called?",
        stage: "recognise",
        options: [
            "A legion",
            "A village",
            "A kingdom",
            "A temple"
        ],

        hint: "Focus on the part of the world mentioned in the description.",

        explanation:
            "A Roman legion was a large group of soldiers.",

        difficulty: 1,
        correctAnswer: "A legion",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-004",
        skillId: "romanArmyAndLife",
        question:
            "What did Roman soldiers wear for protection?",
        stage: "recognise",
        options: [
            "Armour",
            "School uniforms",
            "Modern jackets",
            "Silk robes"
        ],

        hint: "Before houses were built, what natural shelter already existed?",

        explanation:
            "Roman soldiers wore armour and carried shields for protection.",

        difficulty: 1,
        correctAnswer: "Armour",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-005",
        skillId: "romanArmyAndLife",
        question:
            "What weapon did Roman soldiers commonly use?",
        stage: "recognise",
        options: [
            "A sword",
            "A computer",
            "A telescope",
            "A camera"
        ],

        hint: "These animals lived in the wild, not on farms.",

        explanation:
            "Roman soldiers commonly used swords called gladii.",

        difficulty: 1,
        correctAnswer: "A sword",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-006",
        skillId: "romanArmyAndLife",
        question:
            "Why did Roman soldiers build forts?",
        stage: "recognise",
        options: [
            "To control and protect areas",
            "To grow food only",
            "To hold festivals",
            "To avoid travelling"
        ],

        hint: "Think about foods that can be picked rather than hunted.",

        explanation:
            "Forts helped the Romans defend and control their territory.",

        difficulty: 1,
        correctAnswer: "To control and protect areas",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-007",
        skillId: "romanArmyAndLife",
        question:
            "What did Roman roads help with?",
        stage: "recognise",
        options: [
            "Moving soldiers and goods quickly",
            "Growing crops",
            "Building pyramids",
            "Writing books"
        ],

        hint: "Three answers existed then; one belongs to modern life.",

        explanation:
            "Roman roads helped the army travel and helped trade.",

        difficulty: 1,
        correctAnswer: "Moving soldiers and goods quickly",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-008",
        skillId: "romanArmyAndLife",
        question:
            "What language did Romans introduce to Britain?",
        stage: "recognise",
        options: [
            "Latin",
            "Egyptian",
            "Viking",
            "French"
        ],

        hint: "Which choice describes what fire helped people do every day?",

        explanation:
            "Latin was the language used by Romans for government and writing.",

        difficulty: 1,
        correctAnswer: "Latin",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-009",
        skillId: "romanArmyAndLife",
        question:
            "What were Roman baths used for?",
        stage: "recognise",
        options: [
            "Washing, relaxing and socialising",
            "Growing crops",
            "Training animals",
            "Storing weapons only"
        ],

        hint: "Think about what people could make from hunted animals.",

        explanation:
            "Public baths were important places in Roman towns.",

        difficulty: 1,
        correctAnswer: "Washing, relaxing and socialising",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-010",
        skillId: "romanArmyAndLife",
        question:
            "What did Romans build in Britain?",
        stage: "recognise",
        options: [
            "Roads, forts and towns",
            "Airports",
            "Skyscrapers",
            "Railways"
        ],

        hint: "Look for the only statement that fits prehistoric life.",

        explanation:
            "The Romans built many structures that changed Britain.",

        difficulty: 1,
        correctAnswer: "Roads, forts and towns",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-011",
        skillId: "romanArmyAndLife",
        question:
            "Why were Roman soldiers trained carefully?",
        stage: "recognise",
        options: [
                "To work effectively as an army",
                "To avoid following orders",
                "To stop building roads",
                "To become farmers"
        ],

        hint: "Consider the properties needed for a useful tool.",

        explanation:
            "Training helped Roman soldiers fight together successfully.",

        difficulty: 2,
        correctAnswer: "To work effectively as an army",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-012",
        skillId: "romanArmyAndLife",
        question:
            "What was life like in a Roman town?",
        stage: "recognise",
        options: [
            "People could visit shops, baths and markets",
            "Nobody lived there",
            "There were no buildings",
            "Only soldiers could enter"
        ],

        hint: "Hunting gave more than just something to eat.",

        explanation:
            "Roman towns had many facilities for everyday life.",

        difficulty: 2,
        correctAnswer: "People could visit shops, baths and markets",
        estimatedSeconds: 25,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-013",
        skillId: "romanArmyAndLife",
        question:
            "What was a villa?",
        stage: "recognise",
        options: [
            "A large Roman country house",
            "A Roman weapon",
            "A type of road",
            "A soldier's helmet"
        ],

        hint: "Gathering helped when hunting was unsuccessful.",

        explanation:
            "Wealthy Romans often lived in villas.",

        difficulty: 2,
        correctAnswer: "A large Roman country house",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-014",
        skillId: "romanArmyAndLife",
        question:
            "How did Roman rule affect Britain?",
        stage: "recognise",
        options: [
            "It introduced new buildings, roads and customs",
            "It had no effect",
            "It removed all towns",
            "It stopped farming"
        ],

        hint: "A good shelter keeps danger and bad weather out.",

        explanation:
            "Roman rule brought many changes to Britain.",

        difficulty: 2,
        correctAnswer: "It introduced new buildings, roads and customs",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-015",
        skillId: "romanArmyAndLife",
        question:
            "What did Romans use coins for?",
        stage: "recognise",
        options: [
            "Buying and trading goods",
            "Building walls",
            "Writing messages",
            "Making armour"
        ],

        hint: "Choose the answer that lists real benefits of fire.",

        explanation:
            "Coins were used for trade and buying goods.",

        difficulty: 2,
        correctAnswer: "Buying and trading goods",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-016",
        skillId: "romanArmyAndLife",
        question:
            "Why were Roman towns often built near roads?",
        stage: "recognise",
        options: [
            "For easier travel and trade",
            "To avoid people",
            "To stop communication",
            "To prevent farming"
        ],

        hint: "Think about how children helped their families survive.",

        explanation:
            "Roads connected towns and helped movement.",

        difficulty: 2,
        correctAnswer: "For easier travel and trade",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-017",
        skillId: "romanArmyAndLife",
        question:
            "What evidence helps historians learn about Roman Britain?",
        stage: "recognise",
        options: [
            "Buildings, roads, coins and written records",
            "Modern websites only",
            "Future inventions",
            "Stories with no evidence"
        ],

        hint: "Objects left behind can tell historians about the past.",

        explanation:
            "Historians use evidence from the past to understand history.",

        difficulty: 2,
        correctAnswer: "Buildings, roads, coins and written records",
        estimatedSeconds: 25,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-018",
        skillId: "romanArmyAndLife",
        question:
            "Which statement about Roman soldiers is true?",
        stage: "recognise",
        options: [
            "They followed orders and worked together",
            "They had no training",
            "They never travelled",
            "They avoided all battles"
        ],

        hint: "Fire changed daily life long before machines existed.",

        explanation:
            "Teamwork and discipline made the Roman army powerful.",

        difficulty: 2,
        correctAnswer: "They followed orders and worked together",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain", "army"]
    },

    {
        id: "hist-ral-019",
        skillId: "romanArmyAndLife",
        question:
            "Why do we still see Roman roads today?",
        stage: "recognise",
        options: [
            "They were built strongly and lasted a long time",
            "They were built recently",
            "They were made of plastic",
            "They were never used"
        ],

        hint: "Pick the only object that could be made with Stone Age technology.",

        explanation:
            "Roman engineering helped many roads survive for centuries.",

        difficulty: 2,
        correctAnswer: "They were built strongly and lasted a long time",
        estimatedSeconds: 20,

        tags: ["history", "year3", "roman-britain"]
    },

    {
        id: "hist-ral-020",
        skillId: "romanArmyAndLife",
        question:
            "Which sentence best describes Roman life in Britain?",
        stage: "recognise",
        options: [
            "Romans brought new buildings, roads, language and customs",
            "Romans made no changes",
            "Romans removed all towns",
            "Romans only lived in forests"
        ],

        hint: "Eliminate every answer that depends on modern inventions.",

        explanation:
            "Roman rule had a major impact on Britain.",

        difficulty: 2,
        correctAnswer: "Romans brought new buildings, roads, language and customs",
        estimatedSeconds: 25,

        tags: ["history", "year3", "roman-britain"]
    }

    ]

};


export default romanArmyAndLife;

export {

    romanArmyAndLife

};

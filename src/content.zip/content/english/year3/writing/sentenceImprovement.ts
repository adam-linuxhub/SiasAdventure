import {
    MultipleChoiceActivity,
    SkillContent
} from "../../../types";

const sentenceImprovement: SkillContent = {

    skillId: "sentenceImprovement",

    title: "Improving Sentences",

    description:
        "Learn how to improve writing by adding detail, choosing stronger words and making sentences more interesting.",

    version: 1,

    activities: <MultipleChoiceActivity[]>[

    {
        id: "eng-si-001",
        skillId: "sentenceImprovement",
        question:
            "Which sentence is more interesting?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The enormous dog ran across the field.",
            "The dog ran.",
            "A dog.",
            "The ran dog."
        ],

        explanation:
            "Adding describing words gives the reader more information.",

        difficulty: 1,
        correctAnswer: "The enormous dog ran across the field.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-002",
        skillId: "sentenceImprovement",
        question:
            "Improve this sentence:\n\nThe bird flew.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The colourful bird flew gracefully through the sky.",
            "The bird.",
            "Bird flew.",
            "The flew bird."
        ],

        explanation:
            "The improved sentence adds detail about the bird and its action.",

        difficulty: 1,
        correctAnswer: "The colourful bird flew gracefully through the sky.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-003",
        skillId: "sentenceImprovement",
        question:
            "Which word is a stronger verb than 'went'?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "raced",
            "was",
            "said",
            "looked"
        ],

        explanation:
            "'Raced' gives a clearer picture than the general word 'went'.",

        difficulty: 1,
        correctAnswer: "raced",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-004",
        skillId: "sentenceImprovement",
        question:
            "Improve this sentence:\n\nThe cat sat.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The fluffy cat curled up quietly on the soft cushion.",
            "The cat.",
            "The sat cat.",
            "Cat sat."
        ],

        explanation:
            "Adding details helps the reader imagine what is happening.",

        difficulty: 1,
        correctAnswer: "The fluffy cat curled up quietly on the soft cushion.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-005",
        skillId: "sentenceImprovement",
        question:
            "Which adjective improves this sentence?\n\nThe house had a door.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "wooden",
            "went",
            "quickly",
            "jumped"
        ],

        explanation:
            "'Wooden' describes the door and adds detail.",

        difficulty: 1,
        correctAnswer: "wooden",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-006",
        skillId: "sentenceImprovement",
        question:
            "Why do writers add detail to sentences?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "To help readers create a clearer picture",
            "To make writing confusing",
            "To remove meaning",
            "To shorten every sentence"
        ],

        explanation:
            "Details help readers understand and imagine the writing.",

        difficulty: 1,
        correctAnswer: "To help readers create a clearer picture",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-007",
        skillId: "sentenceImprovement",
        question:
            "Which sentence uses the strongest verb?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The lion roared loudly.",
            "The lion made a sound.",
            "The lion did something.",
            "The lion was there."
        ],

        explanation:
            "'Roared' is more precise and interesting than 'made a sound'.",

        difficulty: 1,
        correctAnswer: "The lion roared loudly.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-008",
        skillId: "sentenceImprovement",
        question:
            "Improve this sentence:\n\nThe boy walked.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The tired boy slowly walked home after school.",
            "The boy.",
            "Walked boy.",
            "The walked."
        ],

        explanation:
            "The improved sentence explains more about the action.",

        difficulty: 1,
        correctAnswer: "The tired boy slowly walked home after school.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-009",
        skillId: "sentenceImprovement",
        question:
            "Which word makes this sentence more descriptive?\n\nThe flower grew.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "beautiful",
            "grew",
            "the",
            "a"
        ],

        explanation:
            "'Beautiful' describes the flower.",

        difficulty: 1,
        correctAnswer: "beautiful",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-010",
        skillId: "sentenceImprovement",
        question:
            "A good writer chooses words that are:",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "Interesting and precise",
            "Always the longest",
            "The same every time",
            "Random"
        ],

        explanation:
            "Precise words make writing clearer and more effective.",

        difficulty: 1,
        correctAnswer: "Interesting and precise",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-011",
        skillId: "sentenceImprovement",
        question:
            "Which sentence creates the clearest image?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The tiny golden butterfly fluttered gently above the flowers.",
            "The butterfly moved.",
            "The butterfly was there.",
            "Something flew."
        ],

        explanation:
            "Specific details help the reader picture the scene.",

        difficulty: 2,
        correctAnswer: "The tiny golden butterfly fluttered gently above the flowers.",
        estimatedSeconds: 25,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-012",
        skillId: "sentenceImprovement",
        question:
            "Replace the weak verb:\n\nThe dog went across the garden.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The dog raced across the garden.",
            "The dog was across the garden.",
            "The dog did across the garden.",
            "The dog gardened."
        ],

        explanation:
            "'Raced' is a stronger and more descriptive verb.",

        difficulty: 2,
        correctAnswer: "The dog raced across the garden.",
        estimatedSeconds: 25,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-013",
        skillId: "sentenceImprovement",
        question:
            "Which sentence uses an adverb to improve the writing?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The girl sang beautifully.",
            "The girl sang.",
            "The girl.",
            "The singing girl."
        ],

        explanation:
            "'Beautifully' explains how the girl sang.",

        difficulty: 2,
        correctAnswer: "The girl sang beautifully.",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-014",
        skillId: "sentenceImprovement",
        question:
            "Improve this sentence:\n\nThe storm came.",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The powerful storm crashed across the dark sky.",
            "The storm.",
            "Came storm.",
            "The came."
        ],

        explanation:
            "The improved sentence adds descriptive language.",

        difficulty: 2,
        correctAnswer: "The powerful storm crashed across the dark sky.",
        estimatedSeconds: 25,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-015",
        skillId: "sentenceImprovement",
        question:
            "Which word choice is most precise?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "whispered",
            "talked",
            "said",
            "did"
        ],

        explanation:
            "'Whispered' gives a more exact description of speaking quietly.",

        difficulty: 2,
        correctAnswer: "whispered",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-016",
        skillId: "sentenceImprovement",
        question:
            "Why are powerful verbs useful?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "They make actions clearer for the reader",
            "They remove all details",
            "They make sentences incorrect",
            "They replace punctuation"
        ],

        explanation:
            "Strong verbs help readers understand exactly what happens.",

        difficulty: 2,
        correctAnswer: "They make actions clearer for the reader",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-017",
        skillId: "sentenceImprovement",
        question:
            "Which sentence has the most detail?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The old wooden ship sailed across the rough sea.",
            "The ship sailed.",
            "The ship moved.",
            "A ship."
        ],

        explanation:
            "The sentence includes adjectives and a stronger description.",

        difficulty: 2,
        correctAnswer: "The old wooden ship sailed across the rough sea.",
        estimatedSeconds: 25,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-018",
        skillId: "sentenceImprovement",
        question:
            "What should you check when improving a sentence?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "Does it make the meaning clearer?",
            "Is every word the same length?",
            "Does it have no punctuation?",
            "Is it as short as possible?"
        ],

        explanation:
            "Good improvements make writing clearer and more interesting.",

        difficulty: 2,
        correctAnswer: "Does it make the meaning clearer?",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-019",
        skillId: "sentenceImprovement",
        question:
            "Which sentence is the best improvement?",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "The excited children raced happily towards the playground.",
            "The children.",
            "Children went.",
            "The children did."
        ],

        explanation:
            "The sentence gives detail about who, what and how.",

        difficulty: 2,
        correctAnswer: "The excited children raced happily towards the playground.",
        estimatedSeconds: 25,

        tags: ["english", "writing", "sentence-improvement"]
    },

    {
        id: "eng-si-020",
        skillId: "sentenceImprovement",
        question:
            "Good writers improve sentences by:",
        stage: "recognise",
        hint: "Look for the choice that makes the writing clearer and more descriptive.",
        options: [
            "Adding useful details and choosing better words",
            "Adding random words",
            "Removing all verbs",
            "Making every sentence identical"
        ],

        explanation:
            "Improved writing uses precise vocabulary and clear details.",

        difficulty: 2,
        correctAnswer: "Adding useful details and choosing better words",
        estimatedSeconds: 20,

        tags: ["english", "writing", "sentence-improvement"]
    }

    ]

};


export default sentenceImprovement;

export {

    sentenceImprovement

};